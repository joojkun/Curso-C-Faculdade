#include <stdio.h>
#include <math.h>
#define L 7

void trianguloPascal(int mat[L][L]) {
  // Resultado da soma na forma de potênia
  int pot;
  // Numero de elementos por linha
  int cont = 0;

  // Preenchendo a matriz com zeros
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      mat[i][j] = 0;
    }
  }

  // Triângulo de pascal
  for (int i = 0; i < L; i ++) {
    // Primeiro elemento da fileira
    mat[i][0] = 1;
    // Imprimindo elemento
    printf("%d ", mat[i][0]);
    // Adicionando os outros elementos da fileira
    for (int j = 1; j <= cont; j ++) {
      mat[i][j] = mat[i - 1][j - 1] + mat[i - 1][j];
      printf("%d ", mat[i][j]);
    }
    // Aumentando a quantidade de elementos por fileira
    cont ++;
    printf("\n");
  }
}

int main() {
  // Declarando a matriz
  int mat[L][L];
  // Chamando a função
  trianguloPascal(mat);
  

  return 0;
}
