#include <stdio.h>

int main() {
  #define L 3
  // Matriz
  int mat[L][L];
  // Somas
  int s_coluna, s_fileira, s_diag_1 = 0, s_diag_2 = 0;
  // Verificador igualdade
  int flag = 1;

  // Lendo os valores da matriz
  printf("Digite os valores de uma matriz %dX%d:\n", L, L);
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      printf("%da fileira: ", i+1);
      scanf("%d", &mat[i][j]);
    }
    printf("\n");
  }
  
  // Imprimindo a matriz
  printf("Matriz gerada:\n");
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      // Elemento da matriz
      printf("%d ", mat[i][j]);
    }
    printf("\n");
  }

  // Soma
  for (int i = 0; i < L; i ++) {
    // Coluna e Fileira
    s_coluna = s_fileira = 0;
    for (int j = 0; j < L; j++) {
      s_fileira += mat[i][j];
      s_coluna += mat[j][i];
      // Somando as diagonais
      if (i == 0) {
        s_diag_1 += mat[j][j];
        s_diag_2 += mat[j][L - (j + 1)];
      }
    }
    // Caso as colunas, diagonais ou fileiras sejam diferentes
    if (s_diag_1 != s_diag_2 || s_fileira != s_coluna) {
      flag = 0;
      break;
    }
  }

  // Caso seja um quadrado mágico
  if (flag == 1) {
    printf("E um quadrado magico!");
  }
  else { // Caso não seja
    printf("Nao e um quadrado magico!");
  }

  return 0;
}
