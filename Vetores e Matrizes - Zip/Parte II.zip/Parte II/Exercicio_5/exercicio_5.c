#include <stdio.h>

int main() {
  // Tamanho da matriz
  #define L 4
  // Declarando a matriz
  int mat[L][L];
  // Contador de valores nulos e verificador permutação
  int cont_z = 0, cont_1 = 0, perm_ver = 1;

  // Lendo os valores da matriz
  printf("Digite os valores de uma matriz %dX%d:\n", L, L);
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      printf("%da fileira: ", i+1);
      scanf("%d", &mat[i][j]);
    }
    printf("\n");
  }

  // Imprimindo a matriz
  printf("Matriz gerada:\n");
  for (int i = 0; i < L; i ++) {
    // Resetando os contadores
    cont_z = 0;
    cont_1 = 0;
    for (int j = 0; j < L; j ++) {
      // Elemento da matriz
      printf("%d ", mat[i][j]);
      // Contando o número de valores nulos
      if (mat[i][j] == 0) {
        cont_z += 1;
      }
      // Contando o número de "1"s
      if (mat[i][j] == 1) {
        cont_1 += 1;
      }
    }
    // Verificando se a quantidade de valores zero é igual a n-1
    if (L != cont_z + cont_1 || cont_z  != L - 1) {
      perm_ver = 0;
    }
    printf("\n");
  }

  // Resultado
  if (perm_ver == 1) {
    printf("A matriz e uma matriz de permutacao!");
  }
  else {
    printf("A matriz nao e uma matriz de permutacao!");
  }

  return 0;
}
