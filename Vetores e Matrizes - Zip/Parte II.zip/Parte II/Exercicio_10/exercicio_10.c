#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define L 5

void imprimeMatriz(int mat[L][L]) {
  // Preenchendo a matriz com valores aleatórios
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      mat[i][j] = rand() % 20;
      printf("%.2d ", mat[i][j]);
    }
    printf("\n");
  }

  // Imprimindo a transposta da matriz
  printf("\nTransposta da matriz:\n");
  for (int j = 0; j < L; j ++) {
    for (int i = 0; i < L; i ++) {
      printf("%.2d ", mat[i][j]);
    }
    printf("\n");
  }
}

int main() {
  // Declarando a matriz
  int mat[L][L];
  // Inicializando a biblioteca Rand
  srand(time(NULL));

  // Chamando a função
  imprimeMatriz(mat);

  return 0;
}
