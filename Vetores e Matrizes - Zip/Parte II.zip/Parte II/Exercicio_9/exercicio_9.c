#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define L 5
# define C 10

void preencheGrabarito(char vet[C], int vet_result[C]) {
  // Inicializando a biblioteca Rand
  srand(time(NULL));
  // Valor rand
  int rand_n;

  // Preenchendo o vetor com valores aleatórios
  printf("Gabarito:\n");
  for (int i = 0; i < C; i ++) {
    // Preenchendo o vetor de resultado com valores nulos
    vet_result[i] = 0;
    // Gerando o valor aleatório
    rand_n = rand() % 4;
    rand_n ++;
    // Convertendo em letra
    if (rand_n == 1) {
      vet[i] = 'a';
    }
    else if (rand_n == 2) {
      vet[i] = 'b';
    }
    else if (rand_n == 3) {
      vet[i] = 'c';
    }
    else if (rand_n == 4) {
      vet[i] = 'd';
    }
    // Imprimindo o gabarito
    if (i == C - 1) {
      printf("%c\n", vet[i]);
    }
    else {
      printf("%c, ", vet[i]);
    }
  }

}

void preencheResposta(char mat[L][C]) {
  // Valor rand
  int rand_n;

  // Preenchendo o vetor com valores aleatórios
  for (int i = 0; i < L; i ++) {
    printf("Respostas do aluno %d:\n", i + 1);
    for (int j = 0; j < C; j ++) {
      // Gerando o valor aleatório
      rand_n = rand() % 4;
      rand_n ++;
      // Convertendo em letra
      if (rand_n == 1) {
        mat[i][j] = 'a';
      }
      else if (rand_n == 2) {
        mat[i][j] = 'b';
      }
      else if (rand_n == 3) {
        mat[i][j] = 'c';
      }
      else if (rand_n == 4) {
        mat[i][j] = 'd';
      }
      // Imprimindo respostas
      if (C - 1 == j) {
        printf("%c", mat[i][j]);
      }
      else {
        printf("%c, ", mat[i][j]);
      }
    }
    printf("\n");
  }
}

void comparaResposta(char mat[L][C], char vet[C], int vet_result[C]) {
    // Comparando as respostas para compor as notas
    for (int i = 0; i < L; i ++) {
      for (int j = 0; j < C; j ++) {
        // Caso o aluno acerte a resposta
        if (mat[i][j] ==  vet[j]) {
          vet_result[i] = vet_result[i] + 1;
        }
      }
    }

    // Imprimindo as notas
    for (int i = 0; i < L; i ++) {
      printf("\nNota aluno %d: %d\n", i + 1, vet_result[i]);
    }
    
  }

int main() {
  // Vetor com o gabarito
  char vet[C];
  // Matriz com as repostas dos alunos
  char mat[L][C];
  // Vetor com o resultado
  int vet_result[L];
  // Notas dos alunos
  int nota1 = 0, nota2 = 0, nota3 = 0, nota4 = 0, nota5 = 0;

  // Preenchendo o gabarito
  preencheGrabarito(vet, vet_result);
  // Preenchendo as respostas dos alunos
  preencheResposta(mat);
  // Comparando as respostas
  comparaResposta(mat, vet, vet_result);

  return 0;
}
