#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
  // Declarando a matriz
  int mat[5][5];
  // Inicializando a biblioteca Rand
  srand(time(NULL));

  // Preenchendo a matriz com valores aleatórios
  for (int i = 0; i < 5; i ++) {
    for (int j = 0; j < 5; j ++) {
      mat[i][j] = rand() % 20;
      printf("%.2d ", mat[i][j]);
    }
    printf("\n");
  }

  // Imprimindo a transposta da matriz
  printf("\nTransposta da matriz:\n");
  for (int j = 0; j < 5; j ++) {
    for (int i = 0; i < 5; i ++) {
      printf("%.2d ", mat[i][j]);
    }
    printf("\n");
  }
  return 0;
}
