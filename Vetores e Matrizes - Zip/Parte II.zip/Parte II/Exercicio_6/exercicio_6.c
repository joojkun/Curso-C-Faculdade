#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void cartelaBingo(int mat[5][5]) {
  // Inicializando a biblioteca Rand
  srand(time(NULL));
  // Valor rand
  int rand_n;
  // Vetor com os valores já adicionados
  int vet[25];

  // Preenchendo a matriz com valores nulos
  for (int i = 0; i < 5; i ++) {
    for (int j = 0; j < 5; j ++) {
      mat[i][j] = 0;
    }
  }

  // Preenchendo o vetor com valores nulos
  for (int i = 0; i < 25; i ++) {
    vet[i] = 0;
  } 

  // Preenchendo a matriz com valores aleatórios
  for (int i = 0; i < 5; i ++) {
    for (int j = 0; j < 5; j ++) {
      // Gerando um valor aleatório novo
      rand_n = rand() % 97;
      mat[i][j] = rand_n + 1;

      // Verificando se o valor já está na matriz
      for (int k = 0; k < 25; k ++) {
        // Caso encontre um valor igual
        while (vet[k] == mat[i][j]) {
          // Gerando um valor aleatório novo
          rand_n = rand() % 97;
          mat[i][j] = rand_n + 1;
          // Caso o valor seja diferente do valor atual
          if (mat[i][j] != vet[k]) {
            k = 0;
            break;
          }
        }
      }
      // Adicionando o valor no vetor
      vet[(i * 5) + j - 1] = mat[i][j];
    }
  }
}

void imprimeMatriz(int mat[5][5]) {
  // Imprimindo matriz
  for (int i = 0; i < 5; i ++) {
    for (int j = 0; j < 5; j ++) {
      printf("%.2d ", mat[i][j]);
    }
    printf("\n");
  }
}

int main() {
  // Tamanho da matriz
  #define L 5
  // Declarando a matriz
  int mat[L][L];

  // Gerando a cartela de bingo
  cartelaBingo(mat);
  // Imprimindo a cartela
  imprimeMatriz(mat);

  return 0;
}
