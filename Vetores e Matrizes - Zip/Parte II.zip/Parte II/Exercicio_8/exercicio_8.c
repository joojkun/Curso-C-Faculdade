#include <stdio.h>
#include <math.h>
#define L 3

void gerarMatriz(int mat[L][L]) {
  // Valor que será adicionado na matriz
  int valor_lido;

  // Lendo a matriz
  printf("Digite os elementos de uma matriz %dX%d\n", L, L);
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      // Lendo valor
      printf("Digite um valor: ");
      scanf("%d", &valor_lido);
      // Adicionando valor na matriz
      mat[i][j] = valor_lido;
    }
  }

  // Imprimindo a matriz
  printf("\nMatriz digitada:\n");
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      printf("%d ", mat[i][j]);
    }
    printf("\n");
  }
  printf("\n");

}

void multiplicarMatriz(int mat1[L][L], int mat2[L][L]) {
  // Imprimindo a matriz
  printf("\nC = A * B:\n");
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      printf("%.2d ", mat1[i][j] * mat2[i][j]);
    }
    printf("\n");
  }
  printf("\n");

}

void quadradaMatriz(int mat1[L][L]) {
  // Imprimindo a matriz
  printf("\nC = A^2:\n");
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      printf("%.2d ", mat1[i][j] * mat1[i][j]);
    }
    printf("\n");
  }
  printf("\n");

}

void potenciaMatriz(int mat1[L][L]) {
  // Expoente que será lido e resultado da operação
  int expoente, pot;

  // Lendo o expoente
  printf("\nDigite um expoente:");
  scanf("%d", &expoente);

  // Imprimindo a matriz
  printf("\nC = A^2:\n");
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      pot = pow(mat1[i][j], expoente);
      printf("%.2d ", pot);
    }
    printf("\n");
  }
  printf("\n");

}

int main() {
  // Matrizes
  int mat1[L][L], mat2[L][L];

  // Preenchendo as matrizes
  gerarMatriz(mat1);
  gerarMatriz(mat2);
  // Multiplicando as matrizes
  multiplicarMatriz(mat1, mat2);
  // Quadrado da primeira matriz
  quadradaMatriz(mat1);
  // Primeira matriz elevada a um expoente
  potenciaMatriz(mat1);

  return 0;
}
