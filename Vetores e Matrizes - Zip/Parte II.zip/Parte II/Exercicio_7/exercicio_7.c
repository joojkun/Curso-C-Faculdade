#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void criarMatrizes(int mat1[10][10], int mat2[10][10], int L) {
  // Inicializando a biblioteca Rand
  srand(time(NULL));
  // Valor rand
  int rand_n;

  // Preenchendo a matriz com valores aleatórios
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      rand_n = rand() % 9;
      mat1[i][j] = rand_n + 1;
      rand_n = rand() % 9;
      mat2[i][j] = rand_n + 1;
    }
  }
  // Mensagem após criar as matriz
  printf("Matrizes criadas!\n");

}

void imprimirMatrizes(int mat1[10][10], int mat2[10][10], int L) {
  // Imprimindo as matrizes
  // Primeira Matriz
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      printf("%.2d ", mat1[i][j]);
    }
    printf("\n");
  }
  printf("\n");

  // Segunda Matriz
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      printf("%.2d ", mat2[i][j]);
    }
    printf("\n");
  }
  printf("\n");

}

void somarMatrizes(int mat1[10][10], int mat2[10][10], int L) {
  // Somando as matrizes
  printf("Soma das matrizes:\n");
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      printf("%.2d ", mat1[i][j] + mat2[i][j]);
    }
    printf("\n");
  }
  printf("\n");
}

void subatrairMatrizes(int mat1[10][10], int mat2[10][10], int L) {
  // Subtraindo as matrizes
  printf("Subatracao da primeira pela segunda matriz:\n");
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      printf("%.2d ", mat1[i][j] - mat2[i][j]);
    }
    printf("\n");
  }
  printf("\n");
}

void multiplicarConst(int mat1[10][10], int L, int c) {
  // Subtraindo as matrizes
  printf("Multiplicacao da primeira matriz pela constante %d:\n", c);
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      printf("%.2d ", mat1[i][j] * c);
    }
    printf("\n");
  }
  printf("\n");
}

int main() {
  // Tamanho da matriz
  #define L 10
  // Declarando as matrizes
  int mat1[L][L], mat2[L][L];
  // Flag que diz se opção zero ja foi escolhida
  int flag = 0;
  // Opção escolhida pelo usuário
  int opcao;
  // Constante que será lida
  int c;

  // Opções do menu
  printf("(0) criar duas matrizes 10 x 10 com valores inteiros\n"
         "(1) imprimir as matrizes originais\n"
         "(2) somar as duas matrizes e imprimir o resultado\n"
         "(3) subtrair a primeira matriz da segunda e imprimir o resultado\n"
         "(4) multiplicar uma constante a primeira matriz e imprimir o resultado\n"
         "(5) Encerrar o programa\n");

  // Lendo uma opção
  printf("Selecione uma opcao: ");
  scanf("%d", &opcao);

  while (opcao != 5)
  {
    if (opcao == 0) {
      // Acionando flag
      flag = 1;
      // Criando as matrizes
      criarMatrizes(mat1, mat2, L);
    }
    else if (opcao == 1 && flag == 1) {
      // Imprimir as matrizes
      imprimirMatrizes(mat1, mat2, L);
    }
    else if (opcao == 2 && flag == 1) {
      // Somar as matrizes
      somarMatrizes(mat1, mat2, L);
    }
    else if (opcao == 3 && flag == 1) {
      // Subtrair a primeira matriz da segunda
      subatrairMatrizes(mat1, mat2, L);
    }
    else if (opcao == 4 && flag == 1) {
      // Multiplicar uma constante à primeira matriz e exibir o resultado
      // Lendo a constante
      printf("Digite uma constante: ");
      scanf("%d", &c);
      multiplicarConst(mat1, L, c);
    }
    else {
      printf("As matrizes ainda nao foram geradas!\n");
    }
    // Lendo outra opção do usuário
    printf("Selecione uma opcao: ");
    scanf("%d", &opcao);
  }

  return 0;
}
