#include <stdio.h>
#include <stdlib.h>
#include <time.h>
// Tamanho da matriz
#define L 10

void miniMax(int mat[L][L]) {
  // Valor máximo e valor mínimo
  int max = 0, min = 0;
  // Fileira e coluna do máx e min
  int fileira, coluna;
  // Inicializando a biblioteca Rand
  srand(time(NULL));
  // Valor rand
  int rand_n;

  // Preenchendo a matriz com valores aleatórios
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      rand_n = rand() % 20;
      mat[i][j] = rand_n + 1;
      printf("%.2d ", mat[i][j]);
    }
    printf("\n");
  }

  max = mat[0][0];
  min = mat[0][0];
  fileira = 0;
  coluna = 0;

  // Checando valores máximos e mínimos
  for (int i = 0; i < L; i ++) {
    for (int j = 0; j < L; j ++) {
      // Valor máx
      if (mat[i][j] >= max) {
        max = mat[i][j];
        // Valor mínimo
        for (int k = 0; k < L; k++) {
          if (mat[i][k] <= min) {
            min = mat[i][k];
            fileira = i;
            coluna = k;
          }
        }
      }
    }
  }

  // Resultado
  printf("\nValor max: %d | Valor min: %d | Fileira: %d | Coluna: %d",
    max, min, fileira, coluna);
}

int main() {
  // Declarando a matriz
  int mat[L][L];

  // Chamando a função
  miniMax(mat);

  return 0;
}
