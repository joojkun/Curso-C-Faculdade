#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void preencheVetor(int valor, int vetor[], int len) {
    // Valor aleatório 
    int random_valor;
    // Inicializando a biblioteca Rand
    srand(time(NULL));
    
    // Preenchendo o vetor com numeros aleatórios
    for (int i = 0; i < len; i++) {
        // Gerando o valor aleatório
        random_valor = rand() % valor;
        // Adicionando o valor no vetor
        vetor[i] = random_valor;
    }
}

float mediaElementoPar(int vetor[], int len) {
    // Media dos conteúdos pares
    float media = 0.0;
    // Quantidade de elementos pares
    float cont_par = 0.0;

    for (int i = 0; i < len; i ++) {
        // Caso o valor seja par
        if (vetor[i] % 2 == 0) {
            // Adicionando o valor na média
            media += vetor [i];
            cont_par ++;
        }
    }

    // Calculando a média dos elementos pares do vetor
    media = media / cont_par;
    return media;

}

int main() {
    // Vetor
    int vetor[10];
    // Media dos elementos pares
    float media;

    // Preenchendo o vetor
    preencheVetor(20, vetor, 10);
    // Executando a função
    media = mediaElementoPar(vetor, 10);

    // Imprimindo o vetor
    printf("O vetor e: ");
    for (int i = 0; i < 10; i++) {
        if (i == 9) {
            printf(" %d\n", vetor[i]);
        }
        else {
            printf(" %d,", vetor[i]);
        }
    }
    // Resultado
    printf("A media dos elementos pares do vetor e: %.2f\n", media);
    return 0;
}
