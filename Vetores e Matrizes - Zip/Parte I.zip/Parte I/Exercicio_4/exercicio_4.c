#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void preencheVetor(int valor, int vetor[]) {
    // Valor aleatório 
    int random_valor;
    // Inicializando a biblioteca Rand
    srand(time(NULL));
    
    // Preenchendo o vetor com numeros aleatórios
    for (int i = 0; i < 10; i++) {
        // Gerando o valor aleatório
        random_valor = rand() % valor;
        // Adicionando o valor no vetor
        vetor[i] = random_valor;
    }
}

int main() {
    //Vetor
    int vetor[10];
    // valor que será lido
    int valor_lido;

    // Lendo o valor
    printf("Digite um valor para ser o valor maximo: ");
    scanf("%d", &valor_lido);

    //Executando a função
    preencheVetor(valor_lido, vetor);

    // Imprimindo o vetor
    printf("Vetor gerado: ");
    for (int i = 0; i < 10; i++) {
        if (i == 9) {
            printf(" %d\n", vetor[i]);
        }
        else {
            printf(" %d,", vetor[i]);
        }
    }

}
