#include <stdio.h>
#include <stdlib.h>
#include <time.h>


void preencheVetor(int valor, int v1[], int v2[], int len) {
    // Valor aleatório 
    int random_valor;
    // Inicializando a biblioteca Rand
    srand(time(NULL));
    // Preenchendo o vetor com numeros aleatórios
    for (int i = 0; i < len; i++) {
        // Gerando o valor aleatório
        random_valor = rand() % valor;
        // Adicionando o valor no vetor
        v1[i] = random_valor;
    }
    // Preenchendo o vetor com numeros aleatórios
    for (int i = 0; i < len; i++) {
        // Gerando o valor aleatório
        random_valor = rand() % valor;
        // Adicionando o valor no vetor
        v2[i] = random_valor;
    }
}

void intercalaVetores(int v1[], int v2[], int v3[], int len) {
    // Indice dos vetores
    int index1 = 0, index2 = 0;
    // Imprimindo os vetores
    // Vetor 1    
    printf("Primeiro vetor: ");
    for (int i = 0; i < 4; i++) {
        printf("%d ", v1[i]);
    }
    printf("\n");
    // Vetor 2
    printf("Segundo vetor: ");   
    for (int i = 0; i < 4; i++) {
        printf("%d ", v2[i]);
    }
    printf("\n");

    // Preenchendo o terceiro vetor
    for (int i = 0; i < len; i ++) {
        // Caso o indice seja par
        if (i % 2 == 0) {
            v3[i] = v1[index1];
            index1 ++;
        }
        // Índice Ímpar
        else {
            v3[i] = v2[index2];
            index2 ++;
        }
    }
    // Vetor 3
    printf("Terceiro vetor: ");   
    for (int i = 0; i < 8; i++) {
        printf("%d ", v3[i]);
    }

}

int main() {
    // Vetores
    int vetor_1 [4];
    int vetor_2 [4];
    int vetor_3 [8];


    // Preenchendo os vetores
    preencheVetor(20, vetor_1, vetor_2, 4);
    intercalaVetores(vetor_1, vetor_2, vetor_3, 8);

    return 0;
}
