#include <stdio.h>
/* Implemente um programa em C que preenche os elementos de um vetor de forma a permitir apenas a inserção de
valores distintos. Caso o usuário tente inserir um valor já existente, o programa deve alertar a duplicidade e solicitar
um novo valor. */

int main() {
  // Declarando o vetor
  int vet[5];
  // Valor que será lido
  int valor_lido;
  // Variável que verifica se um valor está na array
  int ver_valor = 0;

  // Lendo os valores
  for (int i = 0; i < 5; i++) {
    // Lendo um valor
    printf("Digite um valor: ");
    scanf("%d", &valor_lido);
    // Verificando se o valor já está na matriz
    for (int ver = 0; ver < 5; ver++) {
      // Caso o valor já esteja na matriz
      if (vet[ver] == valor_lido) {
        ver_valor = 1;
        printf("Este valor ja esta no vetor! Tento outro...\n");
        break;
      }
    }
    while (ver_valor == 1) {
      // Resetando o verificador 
      ver_valor = 0;
      // Lendo um valor
      printf("Digite um valor: ");
      scanf("%d", &valor_lido);
      // Verificando se o valor já está na matriz
      for (int ver = 0; ver < 10; ver++) {
        // Caso o valor já esteja na matriz
        if (vet[ver] == valor_lido) {
          ver_valor = 1;
          printf("Este valor ja esta no vetor! Tento outro...\n");
          break;
        }
      }
    }
    vet[i] = valor_lido;
  }
  // Imprimindo os valores do vetor
  printf("Os valores digitados foram: ");
  for (int i = 0; i < 5; i++) {
    printf("%d, ", vet[i]);
  }

}
