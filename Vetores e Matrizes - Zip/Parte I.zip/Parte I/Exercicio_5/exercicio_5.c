#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void preencheVetor(int valor_min, int valor_max, int vetor[], int len) {
    // Valor aleatório 
    int random_valor;
    // Inicializando a biblioteca Rand
    srand(time(NULL));
    
    // Preenchendo o vetor com numeros aleatórios
    for (int i = 0; i < len; i++) {
        // Gerando o valor aleatório
        random_valor = rand() % valor_max;
        // Mantendo o valor entre o mínimo e o máximo
        while (random_valor < valor_min) {
            random_valor = rand() % valor_max;
        }
        // Adicionando o valor no vetor
        vetor[i] = random_valor;
    }
}

int main() {
    //Vetor
    int vetor[10];
    // valores que serão lidos
    int valor_max, valor_min;

    // Lendo os valores
    printf("Digite um valor para ser o valor minimo: ");
    scanf("%d", &valor_min);
    printf("Digite um valor para ser o valor maximo: ");
    scanf("%d", &valor_max);

    //Executando a função
    preencheVetor(valor_min, valor_max, vetor, 10);

    // Imprimindo o vetor
    printf("Vetor gerado: ");
    for (int i = 0; i < 10; i++) {
        if (i == 9) {
            printf(" %d\n", vetor[i]);
        }
        else {
            printf(" %d,", vetor[i]);
        }
    }

}
