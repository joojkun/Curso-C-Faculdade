#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  // Vetores
  int vet1 [5], vet2 [5];
  // Inicializando a biblioteca Rand
  srand(time(NULL));
  // Valor aleatório
  int rand_value;

  // Preenchendo os vetores
  // Primeiro vetor
  printf("Primeiro vetor: ");
  for (int i = 0; i < 5; i++) {
    // Gerando valor aleatório
    vet1[i] = rand_value = rand() % 20;
    // Imprimindo o valor no vetor
    if (i == 4) {
      printf(" %d\n", vet1[i]);
    }
    else {
      printf(" %d,", vet1[i]);
    }
  }
  // Segundo vetor
  printf("Segundo vetor: ");
  for (int i = 0; i < 5; i++) {
    // Gerando valor aleatório
    vet2[i] = rand_value = rand() % 20;
    // Imprimindo o valor no vetor
    if (i == 4) {
      printf(" %d\n", vet2[i]);
    }
    else {
      printf(" %d,", vet2[i]);
    }
  }

  // Imprimindo a soma dos valores
  printf("Soma dos valores: ");
  for (int i = 0; i < 5; i ++) {
    printf("\n%d + %d = %d", vet1[i], vet2[5 - (i + 1)],
      vet1[i] + vet2[5 - (i + 1)]);
  }

  return 0;
}
  