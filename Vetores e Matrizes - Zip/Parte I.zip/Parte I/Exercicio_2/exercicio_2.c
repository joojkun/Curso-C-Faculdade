#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
  // Declarando o vetor
  int vet[5];
  // Valor que será lido
  int valor_lido;
  // Inicializando a biblioteca Rand
  srand(time(NULL));
  // Números que seram sorteados
  int num_random;

  // Preenchendo o vetor com valores aleatórios
  for (int i = 0; i < 5; i ++) {
    // Gerando o valor aleatório
    num_random = rand() % 10 + 1;
    // Inserindo no vetor
    vet[i] = num_random;
  }
  // Imprimindo o vetor gerado
  printf("O vetor gerado foi: ");
  for (int i = 0; i < 5; i++) {
    if (i == 4) {
      printf("%d\n", vet[i]);
    }
    else {
      printf("%d, ", vet[i]);
    }
  }

  // Lendo um valor digitado pelo usuário
  printf("Digite a posicao que sera removida do vetor (de 0 a 4): ");
  scanf("%d", &valor_lido);

  // "Removendo" a posição da array
  for (int i = valor_lido + 1; i < 5; i ++) {
    vet[i - 1] = vet[i];
  }

  printf("O novo vetor e: ");
  for (int i = 0; i < 4; i ++) {
    if (i == 3) {
      printf("%d\n", vet[i]);
    }
    else {
      printf("%d, ", vet[i]);
    }
  }

  return 0;
}
