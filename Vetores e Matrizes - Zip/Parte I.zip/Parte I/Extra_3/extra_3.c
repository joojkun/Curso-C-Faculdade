#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define T 5

void somaElementos(int vet1[T], int vet2[T]) {
  // Inicializando a biblioteca Rand
  srand(time(NULL));
  // Valor aleatório
  int rand_value;

  // Preenchendo os vetores
  // Primeiro vetor
  printf("Primeiro vetor: ");
  for (int i = 0; i < T; i++) {
    // Gerando valor aleatório
    vet1[i] = rand_value = rand() % 20;
    // Imprimindo o valor no vetor
    if (i == (T - 1)) {
      printf(" %d\n", vet1[i]);
    }
    else {
      printf(" %d,", vet1[i]);
    }
  }
  // Segundo vetor
  printf("Segundo vetor: ");
  for (int i = 0; i < T; i++) {
    // Gerando valor aleatório
    vet2[i] = rand_value = rand() % 20;
    // Imprimindo o valor no vetor
    if (i == (T - 1)) {
      printf(" %d\n", vet2[i]);
    }
    else {
      printf(" %d,", vet2[i]);
    }
  }

  // Imprimindo a soma dos valores
  printf("Soma dos valores: ");
  for (int i = 0; i < T; i ++) {
    printf("\n%d + %d = %d", vet1[i], vet2[T - (i + 1)],
      vet1[i] + vet2[T - (i + 1)]);
  }
}

int main(void) {
  // Vetores
  int vet1 [T], vet2 [T];
  
  //Chamando a função
  somaElementos(vet1, vet2);

  return 0;
}
  