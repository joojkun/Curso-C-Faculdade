#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void preencheVetor(int valor, int vetor[], int len) {
    // Valor aleatório 
    int random_valor;
    // Inicializando a biblioteca Rand
    srand(time(NULL));
    
    // Preenchendo o vetor com numeros aleatórios
    for (int i = 0; i < len; i++) {
        // Gerando o valor aleatório
        random_valor = rand() % valor;
        // Adicionando o valor no vetor
        vetor[i] = random_valor;
    }
}

void imprimeDireta(int vetor[], int len) {
    // Imprimindo o vetor
    printf("O vetor em ordem ordenada e: ");
    for (int i = 0; i < len; i++) {
        if (i == len - 1) {
            printf(" %d\n", vetor[i]);
        }
        else {
            printf(" %d,", vetor[i]);
        }
    }
}

void imprimeIndireta(int vetor[], int len) {
    // Imprimindo o vetor
    printf("O vetor em ordem inversa e: ");
    for (int i = len - 1; i >= 0; i--) {
        if (i == 0) {
            printf(" %d\n", vetor[i]);
        }
        else {
            printf(" %d,", vetor[i]);
        }
    }
}

int main() {
    // Vetor
    int vetor[10];

    // Executando as funções
    // Preenchendo o vetor
    preencheVetor(20, vetor, 10);
    // Ordem direta
    imprimeDireta(vetor, 10);
    // Ordem Indireta
    imprimeIndireta(vetor, 10);

    return 0;
}
