#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define T 5

void removeElemento(int vet[T]) {
  // Valor que será lido
  int valor_lido;
  // Inicializando a biblioteca Rand
  srand(time(NULL));
  // Números que seram sorteados
  int num_random;

  // Preenchendo o vetor com valores aleatórios
  for (int i = 0; i < T; i ++) {
    // Gerando o valor aleatório
    num_random = rand() % 10 + 1;
    // Inserindo no vetor
    vet[i] = num_random;
  }
  // Imprimindo o vetor gerado
  printf("O vetor gerado foi: ");
  for (int i = 0; i < T; i++) {
    if (i == 4) {
      printf("%d\n", vet[i]);
    }
    else {
      printf("%d, ", vet[i]);
    }
  }

  // Lendo um valor digitado pelo usuário
  printf("Digite a posicao que sera removida do vetor (de 0 a %d): ", T - 1);
  scanf("%d", &valor_lido);

  // "Removendo" a posição da array
  for (int i = valor_lido + 1; i < T; i ++) {
    vet[i - 1] = vet[i];
  }

  printf("O novo vetor e: ");
  for (int i = 0; i < (T - 1); i ++) {
    if (i == 3) {
      printf("%d\n", vet[i]);
    }
    else {
      printf("%d, ", vet[i]);
    }
  }
}

int main() {
  // Declarando o vetor
  int vet[T];

  // Chamando a função
  removeElemento(vet);

  return 0;
}
