#include "stdio.h"
/*OBI - Exercício do Bondinho. A turma do colégio vai fazer uma excursão na serra e todos os alunos e monitores vão
tomar um bondinho para subir até o pico de uma montanha. A cabine do bondinho pode levar 50 pessoas no máximo,
contando alunos e monitores, durante uma viagem até o pico. Neste problema, dado como entrada o número de alunos
e o núnero de monitores, você deve implementar um programa que diga se é possível ou não levar todos os alunos e
monitores em apenas uma viagem
*/
void main(){
  /* Variáveis que receberão o numero de alunos em monitores e
   o total de pessoas*/
  int alunos, monitores, total_pessoas;

  // Recebendo o número de alunos
  printf("Digite quantos alunos estarao na viagem: ");
  scanf("%d", &alunos);

  // Recebendo o número de monitores
  printf("Digite quantos monitores estarao na viagem: ");
  scanf("%d", &monitores);

  // Calculando o número total de pessoas que estarão na viagem
  total_pessoas = alunos + monitores;

  // Definindo se poderá ou não ser feita a viagem
  if (total_pessoas <= 50){
    printf("\nHa um total de %d pessoas, contando alunos e monitores,"
           " sendo assim, a viagem podera ser feita!", total_pessoas);
  }
  else if(total_pessoas > 50){
    printf("\nHa um total de %d pessoas, contando alunos e monitores."
           " Como o limite foi ultrapassado, a viagem nao podera ser feita!",
            total_pessoas);

  }
}
