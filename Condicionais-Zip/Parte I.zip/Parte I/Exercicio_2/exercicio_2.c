#include "stdio.h"
/*Faça um programa que tendo como entradas (via teclado) a base e altura de um retângulo, calcule o perímetro (2*base
+ 2*altura) e a área (base*altura) e imprima se o perímetro é maior que a área.*/
void main(){
  // Variaveis correspondetes a base, altura, perímetro e área
  int base, altura, perimetro, area;

  // Recebendo a base
  printf("Digite a base do retangulo: ");
  scanf("%d", &base);

  // Recebendo a altura
  printf("Digite a altura do retangulo: ");
  scanf("%d", &altura);

  // Calculando o perímetro
  perimetro = (2*base) + (2*altura);
  // Calculando a área
  area = base*altura;

  // Comparando os valores
  // Se o perímetro for maior
  if (perimetro > area){
    printf("O perimetro (valor = %d) eh maior do que a area.", perimetro);
  }
  else {
    printf("O perimetro (valor = %d) eh menor do que a area.", perimetro);
  }
}
