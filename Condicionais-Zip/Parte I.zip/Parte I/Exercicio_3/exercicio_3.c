#include "stdio.h"
/*Modifique o programa anterior para que imprima qual dos dois é maior (perímetro ou área). Assuma que nunca podem
ser iguais.*/
void main(){
  // Variaveis correspondetes a base, altura, perímetro e área
  int base, altura, perimetro, area;

  // Recebendo a base
  printf("Digite a base do retangulo: ");
  scanf("%d", &base);

  // Recebendo a altura
  printf("Digite a altura do retangulo: ");
  scanf("%d", &altura);

  // Calculando o perímetro
  perimetro = (2*base) + (2*altura);
  // Calculando a área
  area = base*altura;

  // Comparando os valores
  // Se o perímetro for maior
  if (perimetro > area){
    printf("O perimetro (valor = %d) eh maior do que a area "
           "do retangulo (valor = %d).", perimetro, area);
  }
  // Se a área for maior
  else if(perimetro < area){
    printf("A area (valor = %d) eh maior do que o perimetro do "
           "retangulo (valor = %d).", area, perimetro);
  }
}
