/*
• Qual será a saída se atribuirmos no início os valores 1, 2 e 3 a n1, n2 e n3,
respectivamente?
Resposta: "1 2 3";
• Qual será a saída se atribuirmos no início os valores 20, 10 e 30 a n1, n2 e
n3, respectivamente?
Resposta: "10 20 30";
• Qual será a saída se atribuirmos no início os valores 5*5, n1/2 e n2+1 a n1,
n2 e n3, respectivamente?
Resposta: "12 13 25";
• O que o programa faz, exatamente? Explique o funcionamento do algoritmo.
Resposta: O programa cria 4 variáveis ("n1", "n2", "n3" e aux).
Em seguida, compara os valores de "n2" e "n3". Caso "n2" seja maior ou igual a
"n3", o programa irá atribuir à variável "aux" o valor de "n2".
Depois, irá atribuir à variável "n2" o valor de "n3", e à "n3" o valor de "aux".

Após isso, o programa irá comparar os valores de "n1" e "n2". Caso "n1" seja
maior ou igual a "n2", o programa irá atribuir à "aux" o valor de "n2", à "n1"
o valor de "n2", e à "n2" o valor de "aux".
Logo após, o programa realiza outra comparação de valores, dessa vez entre "n2"
e "n3". Caso "n2" seja maior ou igual a "n3", será atribuído à "aux" o valor de
"n2", à "n2" o valor de "n3", e a "n3" o valor de "aux".
Por fim, o programa irá imprimir na tela  uma mensagem com os valores de "n1",
"n2" e "n3".
*/
