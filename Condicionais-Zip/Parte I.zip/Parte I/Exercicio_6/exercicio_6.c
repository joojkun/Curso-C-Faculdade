#include "stdio.h"
#include "math.h"
#include "stdbool.h"
/*Refaça o exercício anterior para imprimir mensagem raízes imaginárias caso as raízes sejam imaginárias. Caso a
equação possua uma única raíz o programa também deve indicar isso (ou seja que a raiz é única).
*/
void main(){
  // Variáveis da equação
  int var_a, var_b, var_c;
  // Raízes da equação
  float raiz_1, raiz_2;

  // Recebendo os valores das Variáveis
  printf("Digite o valor de a: ");
  scanf("%d", &var_a); // Variável a
  printf("Digite o valor de b: ");
  scanf("%d", &var_b); // Variável b
  printf("Digite o valor de c: ");
  scanf("%d", &var_c); // Variável c

  /* Quando a raíz de um número é negativa, trata-se de
   um número imaginário. Sendo assim, serão verificadas as raízes usadas
   na fórmula de Bhaskara. Caso sejam negativas, serão consideradas
   como números imaginários, e não serão impressos na tela*/

  // Verificando as raízes
  float delta_x1 = pow(var_b, 2) - 4*var_a*var_c;
  // Caso a raiz seja positiva, tratando-se de um número real
  if (delta_x1 > 0){
    // Calculando as raízes da equação
    // Raiz X1
    raiz_1 = (-(var_b) + sqrt(pow(var_b, 2) - 4*var_a*var_c))/(2*var_a);
    // Raiz X2
    raiz_2 = (-(var_b) - sqrt(pow(var_b, 2) - 4*var_a*var_c))/(2*var_a);
    // Imprimindo o Resultado
    printf("As raizes da equacao sao: [%.2f, %.2f].\n", raiz_1, raiz_2);
  }
  // Raíz imaginária
  else if (delta_x1 < 0){
    // Imprimindo o Resultado
    printf("As raizes sao imaginarias.\n", raiz_1, raiz_2);
  }
  // Raíz Única
  else{
    // Imprimindo o Resultado
    printf("A raiz e unica [%.2f].\n", raiz_1);

  }
}
