#include <stdio.h>
/*Dadas a data atual e a data de nascimento de uma pessoa:
•(a) calcular a sua idade.
Complete o programa do item anterior, informando também
•(b) o dia da semana em que a pessoa nasceu
Dica: uma possibilidade éhttps://pt.wikipedia.org/wiki/Congruência_de_Zeller

h é o dia da semana (0 = sábado, 1 = domingo, 2 = segunda, …)
q é o dia do mês
m é o mês (3 = março, 4 = abril, 5 = maio, …)
K é o ano do século (ano mod 100)
J é o século ([ano/100]) (por exemplo, para 1995 o século seria 19, ainda
 que na realidade o século seria XX)
*/

int main() {
  // Data de nascimento e idade
  int dia, mes, ano, idade;
  // Dia da Semana, Ano do Século e Século
  int dia_semana, ano_seculo, seculo;

  // Recolhendo a data de nascimento do usuário
  printf("Digite o dia (dd) em que voce nasceu: ");
  scanf("%d", &dia); // Dia
  printf("Digite o numero do mes (mm) em que voce nasceu: ");
  scanf("%d", &mes); // Mês
  // Janeiro e Fevereiro serão contados como 13 e 14 respectivamente
  // Janeiro
  if (mes == 1){
    mes = 13;
  }
  // Fevereiro
  if (mes == 2){
    mes = 14;
  }
  printf("Digite o ano (aaaa) em que voce nasceu: ");
  scanf("%d", &ano); // Ano
  // Calculando a idade do usuário
  idade = 2022 - ano;
  printf("Voce tem %d anos\n", idade);

  ano_seculo = (ano % 100);
  seculo = (ano/100);
  // Calculando o dia da semana em que o usuário nasceu
  dia_semana = ((dia + (((mes + 1)*26)/10) + ano_seculo + (ano_seculo/4) +
               (seculo/4) + 5*seculo)) % 7;
  if (dia_semana == 0){
    printf("Voce nasceu em um Sabado!\n");

  }
  else if (dia_semana == 1){
    printf("Voce nasceu em um Domingo!\n");

  }
  else if (dia_semana == 2){
    printf("Voce nasceu em uma Segunda-Feira!\n");

  }
  else if (dia_semana == 3){
    printf("Voce nasceu em uma Terca-Feira!\n");

  }
  else if (dia_semana == 4){
    printf("Voce nasceu em uma Quarta-Feira!\n");

  }
  else if (dia_semana == 5){
    printf("Voce nasceu em uma Quinta-Feira!\n");

  }
  else if (dia_semana == 6){
    printf("Voce nasceu em uma Sexa-Feira!\n");
  }
  return 0;
}
