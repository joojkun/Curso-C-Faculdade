#include "stdio.h"
#include "math.h"
#include "stdbool.h"
/*Faça um programa que dados os coeficientes (a, b e c) de uma equação do 2o grau, calcule e imprima suas raízes (caso
a equação possua raízes imaginárias, o programa não deve imprimir nada).
*/
void main(){
  // Variáveis da equação
  int var_a, var_b, var_c;
  // Raízes da equação
  float raiz_1, raiz_2;

  // Recebendo os valores das Variáveis
  printf("Digite o valor de a: ");
  scanf("%d", &var_a); // Variável a
  printf("Digite o valor de b: ");
  scanf("%d", &var_b); // Variável b
  printf("Digite o valor de c: ");
  scanf("%d", &var_c); // Variável c

  /* Quando a raíz de um número é negativa, trata-se de
   um número imaginário. Sendo assim, serão verificadas as raízes usadas
   na fórmula de Bhaskara. Caso sejam negativas, serão consideradas
   como números imaginários, e não serão impressos na tela*/

  // Verificando as raízes
  float delta = pow(var_b, 2) - 4*var_a*var_c;
  // Caso a raiz seja positiva, tratando-se de um número real
  if (delta >= 0){
    // Calculando as raízes da equação
    // Raiz X1
    raiz_1 = (-(var_b) + sqrt(pow(var_b, 2) - 4*var_a*var_c))/(2*var_a);
    // Raiz X2
    raiz_2 = (-(var_b) - sqrt(pow(var_b, 2) - 4*var_a*var_c))/(2*var_a);
    // Imprimindo o Resultado
    printf("As raizes da equacao sao: [%.2f, %.2f].\n", raiz_1, raiz_2);
  }
}
