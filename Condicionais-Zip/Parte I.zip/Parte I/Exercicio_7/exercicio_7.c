#include <stdio.h>
/*Leia 2 valores reais (xey), os quais representam as coordenadas de um ponto em
um plano. A seguir, determine aqual quadrante pertence o ponto.
Analise também se está sobre um dos eixos cartesianos ou na origem (x=y=0).
Para auaxiliar a resoluação do exercícico, a figura abaixo ilustra os quatro
quadrantes no plano cartesianoXˆY, comoprimeiro quadrante iniciando no canto
superior direito, o segundo no canto superior esquerdo e assim por diante.*/

int main() {
  // Valores X e Y
  float var_x, var_y;

  // Lendo os valores de X e Y
  printf("Digite o primeiro valor: ");
  scanf("%f", &var_x); // Valor de X
  printf("Digite o segundo valor: ");
  scanf("%f", &var_y); // Valor de Y
  // Valores Digitados
  printf("As coordenadas do plano sao [%.2f, %.2f]\n", var_x, var_y);

  // Verificando o quadrante da Coordenada
  // 1o Quadrante
  if (var_x > 0 && var_y > 0){
    printf("A coordenada pertence ao primeiro quadrante!");
  }
  // 2o Quadrante
  else if (var_x < 0 && var_y > 0){
    printf("A coordenada pertence ao segundo quadrante!");
  }
  // 3o Quadrante
  else if (var_x < 0 && var_y < 0){
    printf("A coordenada pertence ao terceiro quadrante!");
  }
  // 4o Quadrante
  else if (var_x > 0 && var_y < 0){
    printf("A coordenada pertence ao quarto quadrante!");
  }

  // Origem
  else if (var_x == 0 && var_y == 0){
    printf("A coordenada pertence ao ponto de origem do grafico");
  }

  // Eixo X
  else if (var_x > 0 && var_y == 0){
    printf("A cordenada esta sobre o eixo x");
  }
  // Eixo Y
  else if (var_x == 0 && var_y > 0){
    printf("A cordenada esta sobre o eixo y");
  }

  return 0;
}
