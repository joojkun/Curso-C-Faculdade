#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
  // Variável de tempo
  time_t segundos;
  // Inicializando a biblioteca Rand
  srand(time(NULL));
  // Números que seram sorteados
  int num_random_1, num_random_2, operacao;
  // Resultado que o usuário irá digitar e o resultado certo
  int resultado, resultado_certo;
  // Gerando os números
  num_random_1 = rand() % 100; // 1o num
  num_random_2 = rand() % 100; // 2o num
  operacao = rand() % 4; // Operação que será realizada
  // Medindo o tempo de resposta do usuário
  segundos = time(NULL);

  // Realizando a operação de acordo com o número gerado
  if (operacao == 0){
    // Soma
    resultado_certo = num_random_1 + num_random_2;
    printf("Resolva o seguinte problema: %d + %d = ",
           num_random_1, num_random_2);
    scanf("%d", &resultado);
  }
  else if (operacao == 1){
    // Subtração
    resultado_certo = num_random_1 - num_random_2;
    printf("Resolva o seguinte problema: %d - %d = ",
           num_random_1, num_random_2);
    scanf("%d", &resultado);
  }
  else if (operacao == 2){
    // Multiplicação
    resultado_certo = num_random_1 * num_random_2;
    printf("Resolva o seguinte problema: %d X %d = ",
           num_random_1, num_random_2);
    scanf("%d", &resultado);
  }
  else if (operacao == 3){
    // Quociente da Divisão
    resultado_certo = num_random_1 / num_random_2;
    printf("Resolva o seguinte problema: %d / %d = ",
           num_random_1, num_random_2);
    scanf("%d", &resultado);
  }
  else if (operacao == 4){
    // Resto da Divisão
    resultado_certo = num_random_1 % num_random_2;
    printf("Resolva o seguinte problema: resto da divisao"
           "de %d por %d = ", num_random_1, num_random_2);
    scanf("%d", &resultado);
  }

  // Verificando se o usuário acertou a questão
  // Caso acerte
  if (resultado == resultado_certo){
    printf("Parabens, voce acertou a resposta!\n");
  }
  // Caso Erre
  else{
    printf("Voce errou... Tente novamente!\n");
  }
  // Dizendo quanto tempo o usuário levou para responder
  printf("Voce levou %d segundos para responder!\n", time(NULL) - segundos);
  return 0;
}
