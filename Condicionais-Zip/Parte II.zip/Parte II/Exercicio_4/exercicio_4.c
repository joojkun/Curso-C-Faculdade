#include <stdio.h>

/*Dados 3 valores A, B, C (lados do triângulo) fornecidos pelo usuário via teclado, implemente um programa para verificar
se estes valores formam um triângulo, e em caso afirmativo, classificá-lo como equilátero, isósceles ou escaleno (imprimir
mensagem informando o tipo ou uma mensagem específica caso não formem um triângulo).
*/
int main(){
  // Lados do triângulo
  int lado_a, lado_b, lado_c;

  // Recebendo os valores dos Lados
  // Lado A
  printf("Digite o valor de um lado do triangulo: ");
  scanf("%d", &lado_a);
  // Lado B
  printf("Digite o valor do segundo lado do triangulo: ");
  scanf("%d", &lado_b);
  // Lado C
  printf("Digite o valor do terceiro lado do triangulo: ");
  scanf("%d", &lado_c);

  // Classificando o tipo de triângulo
  // Triângulo escaleno
  if (lado_a != lado_b && lado_b != lado_c && lado_a != lado_c){
    printf("O triangulo eh escaleno!\n");
  }
  // Triângulo Equilátero
  else if (lado_a == lado_b && lado_b == lado_c && lado_a == lado_c){
    printf("O triangulo eh equilatero!\n");
  }
  // Triângulo Isócsceles
  else if (lado_a == lado_b || lado_b == lado_c || lado_a == lado_c){
    printf("O triangulo eh isosceles!\n");
  }
  return 0;
}
