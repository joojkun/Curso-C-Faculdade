#include <stdio.h>

int main(){
  // Cordenadas da quadra
  int coord_x = 432, coord_y = 468;
  // Cordenadas que o usuário irá digitar
  int coord_ball_x, coord_ball_y;

  // Recebendo as coordenadas da bola
  printf("Digite a coordenada(x, y) do ponto de contato da bola: ");
  scanf("%d %d", &coord_ball_x, &coord_ball_y);

  // Verificando se a bola bateu na semi-quadra
  // Bola Fora
  if (coord_ball_x > coord_x || coord_ball_y > coord_y){
    printf("f\n");
  }
  // Bola Dentro
  else if (coord_ball_x <= coord_x && coord_ball_y <= coord_y){
    printf("d\n");
  }
  return 0;
}
