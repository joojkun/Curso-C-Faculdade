#include <stdio.h>

int main(){
  // Kilometros por litro que um carro bicombustível roda
  float km_gasolina, km_alcool;
  // Preço do litro de gasolina e álcool
  float gasolina_preco, alcool_preco;
  // Preço para rodar com álcool e gasolina
  float preco_total_alcool, preco_total_gasolina;

  // Lendo o rendimento com Gasolina e Álcool
  printf("Digite rendimento por litro da gasolina (km/l): ");
  scanf("%f", &km_gasolina);
  // Lendo o preço do álcool
  printf("Digite rendimento por litro do alcool (km/l): ");
  scanf("%f", &km_alcool);

  // Lendo o preço da gasolina
  printf("Digite o preco do litro de gasolina: ");
  scanf("%f", &gasolina_preco);
  // Lendo o preço do álcool
  printf("Digite o preco do litro de alcool: ");
  scanf("%f", &alcool_preco);

 // Calculando os gastos finais baseados no preço do álcool e gasolina
 preco_total_alcool = alcool_preco / km_alcool;
 preco_total_gasolina = gasolina_preco / km_gasolina;

 // Comparando os preços de R$ por litro
 // Caso a gasolina seja mais econômica
 if (preco_total_alcool >= preco_total_gasolina){
   printf("G\n");
 }
 // Caso o álcool seja mais econômico
else{
  printf("A\n");
}
  return 0;
}
