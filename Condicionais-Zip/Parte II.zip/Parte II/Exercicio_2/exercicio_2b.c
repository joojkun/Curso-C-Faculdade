#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>
/*Faça um programa que
a) recebe como entrada via teclado uma opção e três valores. O programa deve
calcular e imprimir uma média
correspondente a uma das seguintes opções:
• A = média aritmética.
• P = média ponderada com pesos 1, 2 e 3 para o primeiro, segundo e terceiro
valor, respectivamente.
• G = média geométrica.
• H = média harmônica.

O programa deve aceitar as opções tanto em caracteres maiúsculos como
minúsculos.
O programa deve exibir uma mensagem de erro caso a opção escolhida seja inválida.

b) Modifique o programa anterior para que a leitura dos valores seja feita antes
da leitura das operações. Lembre-se do exercício da lista de variáveis que
alterna a ordem de leitura dos tipos char com os tipos tipos int ou float.
*/
int main(){
  // Valores que serão lidos
  float valor_1, valor_2, valor_3;
  // Opção que será lida
  char opcao;
  // Operações matemáticas que serão realizadas
  float media_aritmetica, media_ponderada, media_geometrica, media_harmonica;
  // Multiplicação dos valores para a media geometrica
  float multiplicacao_n;

  // Lendo os valores
  printf("Digite um valor: ");
  scanf("%f", &valor_1); // Primeiro Valor
  printf("Digite um segundo valor: ");
  scanf("%f", &valor_2); // Segundo Valor
  printf("Digite um terceiro valor: ");
  scanf("%f", &valor_3); // Terceiro Valor

  // Lendo uma opção
  printf("Digite uma letra correspondete a uma das opcoes a seguir:\n"
         "- A: Media Aritmetica;\n"
         "- P: Media ponderada com pesos 1, 2 e 3 para o primeiro, segundo e"
         " terceiro valor, respectivamente;\n"
         "- G: Media Geometrica;\n"
         "- H: Media Harmonica;\n");
  scanf("%c");
  scanf("%c", &opcao);
  // Deixando a letra maiúscula
  opcao = toupper(opcao);

  // Executando a opção selecionada pelo usuário
  // Média aritmética
  if (opcao == 'A'){
    // Realizando a operação
    media_aritmetica = (valor_1 + valor_2 + valor_3)/3;
    printf("O resultado da media aritmetica e: %.2f\n", media_aritmetica);
  }
  // Média ponderada
  else if (opcao == 'P'){
    // Realizando a operação
    media_ponderada = ((valor_1*1) + (valor_2*2) + (valor_3*3)) / 6;
    printf("O resultado da media ponderada e: %.2f\n", media_ponderada);
  }
  // Média geométrica
  else if (opcao == 'G'){
    // Realizando a operação
    // Multiplicando o conjunto de dados
    multiplicacao_n = valor_1 * valor_2 * valor_3;
    media_geometrica = pow(multiplicacao_n, 1.0/3);
    printf("O resultado da media geometrica e: %.2f\n", media_geometrica);
  }
  // Média harmônica
  else if (opcao == 'H'){
    // Realizando a operação
    media_harmonica = 3 / (1/valor_1 + 1/valor_2 + 1/valor_3);
    printf("O resultado da media harmonica e: %.2f\n", media_harmonica);

  }
  // Caso não escolha nenhuma das opções
  else{
    printf("A opcao selecionada e invalida...\n");
  }
  return 0;
}
