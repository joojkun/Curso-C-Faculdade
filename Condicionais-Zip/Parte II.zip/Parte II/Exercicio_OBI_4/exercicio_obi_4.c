#include <stdio.h>

 int main(){
  // Dimensões da Janela
  float comprimento_janela, largura_janela;
  // Dimensões da Caixa
  float altura_caixa, largura_caixa, comprimento_caixa;

  // Lendo as dimensões da janela
  // Comprimento
  printf("Digite o valor(cm) do comprimento da Janela: ");
  scanf("%f", &comprimento_janela);
  // Largura
  printf("Digite o valor(cm) da largura da Janela: ");
  scanf("%f", &largura_janela);

  // Verificando se o valor cumpre os requisitos
  if (largura_janela < 1 || largura_janela > 100 ||
      comprimento_janela < 1 || comprimento_janela > 100)
  {
     printf("Os valores da largura/comprimento da janela devem"
          "estar entre (1, 100)!\n");
   // Encerrando o programa
   return 0;
  }

 // Lendo as dimensões da caixa
 // Comprimento
 printf("Digite o valor(cm) do comprimento da caixa: ");
 scanf("%f", &comprimento_caixa);
 // Largura
 printf("Digite o valor(cm) da largura da caixa: ");
 scanf("%f", &largura_caixa);
 // Altura
 printf("Digite o valor(cm) da altura da caixa: ");
 scanf("%f", &altura_caixa);

  // Verificando se o valor cumpre os requisitos
  if (largura_caixa < 1 || largura_caixa > 100 ||
      comprimento_caixa < 1 || comprimento_caixa > 100 ||
      altura_caixa < 1 || altura_caixa > 100)
  {
     printf("Os valores da largura/comprimento/altura da caixa devem"
           "estar entre (1, 100)!\n");
    // Encerrando o programa
    return 0;
  }

  // Verificando se a caixa consegue passar pela janela
  // Caso passe
  if (largura_caixa < largura_janela && altura_caixa < comprimento_janela){
    printf("S\n");
  }
  // Caso passe, mas rotacionando
  else if (comprimento_caixa < largura_janela &&
           altura_caixa < comprimento_janela)
  {
     printf("S\n");
  }
  // Caso não passe
  else{
    printf("N\n");
  }

  return 0;
 }
