#include <stdio.h>
#include <math.h>

/*Escreva um programa que leia um número inteiro no intervalo [100;999] e
verifique se é um número Armstrong. O programa deve imprimir uma mensagem de
erro caso o número fornecido esteja fora do intervalo.*/

int main(){
  // Partes do Número
  int centena, dezena, unidade;
  // Número que será lido
  int valor;
  // Regra Armstrong
  int regra_armstrong;

  // Lendo o valor
  printf("Digite um numero inteiro no intervalo [100 : 999]: ");
  scanf("%d", &valor);

  // Verificando se trata-se de um valor Armstrong
  centena = valor / 100;
  dezena = (valor - ((valor/100) * 100))/10;
  unidade = valor % 10;
  regra_armstrong = pow(centena, 3) + pow(dezena, 3) + pow(unidade, 3);

  // Verificando se o resultado bate com o número oferecido pelo usuário
  // Caso seja igual
  if (regra_armstrong == valor){
    printf("%d eh um numero Armstrong!\n", valor);
  }
  // Caso seja diferente
  else{
    printf("%d nao eh um numero Armstrong.\n", valor);
  }
  return 0;
}
