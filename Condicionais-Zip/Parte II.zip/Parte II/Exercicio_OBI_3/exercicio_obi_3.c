#include <stdio.h>

int main(){
  // Quantidade em m³ de consumo de água
  int consumo;
  // Quantidade a pagar
  int valor_total = 7;

  printf("Digite: ");
  scanf("%d", &consumo);

  // Entre 11m³ e 30m³
  if (consumo <= 30){
    valor_total += -((consumo - 11) * (-1))  + 1;
  }
  else{
    valor_total += 20;
  }
  // Entre 31m³ e 100m³
  if (consumo <= 100){
    valor_total += -((consumo - 31) * (-2)) + 2;
  }
  else{
    valor_total += 140;
  }
  // Acima de 101m³
  if (consumo >= 101){
    valor_total += -((consumo - 100) * (-5));
  }

  // Valor total a pagar
  printf("O total a pagar sera: %d R$\n", valor_total);
  return 0;
}
