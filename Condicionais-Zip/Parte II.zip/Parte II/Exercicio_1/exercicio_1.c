#include <stdio.h>
#include <stdbool.h>
/*Faça um programa que leia do teclado um ano e imprima na tela se ele é ou não
bissexto. Obs.: um ano será bissexto se: (a) for divisível por 400 OU (b) se for
divisível por 4 e não o for por 100. Você deve fazer este exercício usando
apenas apenas uma estrutura if-else.
Dica: explore o uso dos operadores lógicos!
*/
int main(){
  // Ano
  int ano;
  // Recebendo o valor do Ano
  printf("Digite um ano (aaaa): ");
  scanf("%d", &ano);

  // Verificando se o ano é bissexto
  // Caso seja bissexto
  if (ano % 400 == 0 || ano % 4 == 0){
    printf("O Ano e bissexto!\n");
  }
  // Caso não seja bissexto
  else{
    printf("O Ano nao e bissexto!\n");
  }
  return 0;
}
