#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int * criaVetor(int tam, int lim) {
  // Vetor
  int *v;
  // Valor que será gerado aleatoriamente
  int rand_v;
  // Inicializando a biblioteca rand
  srand(time(NULL));

  // Alocando a memória
  v = (int *)malloc(tam*sizeof(int));

  // Preenchendo o vetor
  for (int i = 0; i < tam; i ++) {
    // Gerando um valor aleatório
    rand_v = rand() % lim;
    // Adicionando valor no vetor
    v[i] = rand_v;
  }

  // Retornando o vetor
  return v;
}

int * expandeVetor(int *v, int tam, int n, int lim) {
  // Valores aleatórios que serão adicionados no vetor
  int rand_v;

  // Expandindo o vetor
  v = (int *)realloc(v, n*sizeof(int));

  // Preenchendo o vetor com novos valores
  for (int i = tam; i < tam + n; i ++) {
    // Gerando um valor aleatório
    rand_v = rand() % lim;
    // Adicionando valor no vetor
    v[i] = rand_v;
  }

  // Retornando o vetor
  return v;
}

int main() {
  // Vetor
  int *vetor;
  // Tamanho do vetor e limite
  int tam, lim;
  // Valor de expansão do vetor
  int exp_n;

  // Lendo tamanho e limite do vetor
  printf("Digite o tamanho desejado para o vetor: ");
  scanf("%d", &tam); // Tamanho
  printf("Digite o limite do tamanho dos valores que serao adicionados: ");
  scanf("%d", &lim); // Limite
  // Gerando o vetor com valores aleatórios
  vetor = criaVetor(tam, lim);

  // Imprimindo o vetor
  for (int i = 0; i < tam; i ++) {
    printf("vetor[%d] = %d\n", i, vetor[i]);
  }

  // Modificando o tamanho do vetor
  printf("\nDigite quantos valores novos deseja adicionar ao vetor: ");
  scanf("%d", &exp_n);

  // Expandindo o vetor
  expandeVetor(vetor, tam, exp_n, lim);

  // Imprimindo novos valores do vetor
  printf("Os novos valores adicionados foram:\n");
  for (int i = tam; i < tam + exp_n; i ++) {
    printf("vetor[%d] = %d\n", i, vetor[i]);
  }

  // Limpando memória reservada ao vetor
  free(vetor);

  return 0;
}
