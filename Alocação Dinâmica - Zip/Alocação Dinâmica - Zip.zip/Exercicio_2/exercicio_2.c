#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int * preencheVetor(int *vetor, int tam) {
  // Inicializando a biblioteca rand
  srand(time(NULL));
  // Valor aleatório
  int rand_v;
  // Gerando um vetor de tamanho tam
  vetor = (int *)malloc(tam*sizeof(int));

  // Preenchendo o vetor com números aleatórios
  for (int i = 0; i < tam; i ++) {
    rand_v = rand() % 10;
    vetor[i] = rand_v;
  }

  return vetor;
}

int * multiplicaVetor(int *v1, int *v2, int *v3, int tam1, int tam2) {
  // Tamanho do terceiro vetor
  int tam3 = tam1 * tam2;
  // Índice de valores do terceiro vetor
  int cont = 0;

  // Criando um vetor para armazenar os valores da multiplicação dos vetores
  v3 = (int *)malloc(tam3*sizeof(int));

  // Multiplicando os vetores
  for (int i = 0; i < tam1; i ++) {
    for (int j = 0; j < tam2; j ++) {
      v3[cont] = v1[i] * v2[j];
      cont ++;
    }
  }

  return v3;
}

void imprimeVetor(int vetor[], int tam) {
  // Imprimindo o vetor
  for (int i = 0; i < tam; i ++) {
    if (i == tam - 1) {
      printf("%d\n", vetor[i]);
    }
    else {
      printf("%d, ", vetor[i]);
    }
  }
}

int main() {
  // Vetores que serão alocados
  int *vet_1, *vet_2;
  // Tamanho dos vetores
  int tam_1, tam_2;
  // Multiplicação dos dois vetores
  int *vet_3;

  // Lendo o primeiro vetor
  printf("Digite o tamanho do primeiro vetor: ");
  scanf("%d", &tam_1);

  // Gerando e imprimindo primeiro vetor
  vet_1 = preencheVetor(vet_1, tam_1); // Vetor 1
  printf("Primeiro vetor:\n");
  imprimeVetor(vet_1, tam_1);


  // Lendo o segundo vetor
  printf("Digite o tamanho do segundo vetor: ");
  scanf("%d", &tam_2);

  // Gerando e imprimindo segundo vetor
  vet_2 = preencheVetor(vet_2, tam_2); // Vetor 2
  printf("Segundo vetor:\n");
  imprimeVetor(vet_2, tam_2);

  // Gerando o terceiro vetor
  vet_3 = multiplicaVetor(vet_1, vet_2, vet_3, tam_1, tam_2);

  // Imprimindo o terceiro vetor
  printf("A multiplicacao dos dois vetores e:\n");
  imprimeVetor(vet_3, tam_1 * tam_2);

  // Liberando memória reservada aos vetores
  free(vet_1);
  free(vet_2);
  free(vet_3);

  return 0;
}
