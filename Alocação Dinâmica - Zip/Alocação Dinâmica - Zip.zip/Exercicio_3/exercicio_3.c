#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int elementosVetor(int vetor[], int tam) {
    // Vetor com os elementos do vetor original
    int *v;
    // Número de elementos do vetor 
    int v_tam = 0;
    // Flag igualdade de valores
    int valor_igual = 0;

    // Criando o vetor
    v = (int *)malloc(0*sizeof(int));

    // Contando o número de elementos únicos do vetor
    for (int i = 0; i < tam; i ++) {
        // Verificando se o valor é repetido
        for (int j = 0; j < i; j ++) {
            // Caso o valor seja repetido
            if (vetor[j] == vetor[i]) {
                valor_igual = 1;
                break;
            }
        }
        // Adicionando ou não valor no vetor
        if (valor_igual != 1) {
            v = (int *)realloc(v, (i+1)*sizeof(int));
            v[v_tam] = vetor[i];
            v_tam ++;
        }
        valor_igual = 0;
    }

    printf("\nValores do primeiro vetor:\n");
    for (int i = 0; i < v_tam; i ++) {
        printf("vetor[%d] = %d\n", i, v[i]);
    }
    printf("Numero de elementos do vetor: %d", v_tam);

    return v_tam;
}

int main() {
    // Inicializando a biblioteca rand
    srand(time(NULL));
    // Declaração do vetor
    int vetor[6];
    // Valor aleatório que sera gerado
    int rand_v;

    // Preenchendo o vetor
    printf("Vetor original:\n");
    for (int i = 0; i < 6; i ++) {
        rand_v = rand() % 20;
        vetor[i] = rand_v;
        printf("vetor[%d] = %d\n", i, vetor[i]);
    }

    // Executando a função
    elementosVetor(vetor, 6);
    
    return 0;
}
