#include <stdio.h>
#include <stdlib.h>

int custoCidades(int* cidades, int n_cidades, int** m) {
  // Custo do itinerário
  int custo = 0;

  // Calculando o custo do itinerário
  for (int i = 1; i < n_cidades; i ++) {
    custo += m[cidades[i - 1]][cidades[i]];
  }

  return custo;
}

int main() {
  // Matriz de preço
  int **mat;
  // Lista de cidades e cidades que serão visitadas
  int *vetor, num_cidades, visit_cidades;
  // Custo do itinerário
  int custo = 0;
  // Itinerário;
  int *itinerario;

  // Lendo a lista de cidades
  printf("Digite o total de cidades: ");
  scanf("%d", &num_cidades);

  // Mostrando o código das cidades
  printf("O codigo das cidades sera:\n");
  for (int i = 0; i < num_cidades; i ++) {
    if (i == num_cidades - 1) {
      printf("e Cidade %d;\n", i);
    }
    else {
      printf("Cidade %d, ", i);
    }
  }

  // Criando a matriz com os custos de viagem das cidades
  mat = (int **)malloc(num_cidades*sizeof(int *));
  // Preenchendo a matriz com o custo de cada viagem
  printf("\n");
  for (int i = 0; i < num_cidades; i ++) {
    mat[i] = (int *)malloc(num_cidades*sizeof(int));
    // Preenchendo a fileira da matriz com o custo
    for (int j = 0; j < num_cidades; j ++) {
      printf("Digite o custo de ir da cidade %d para a cidade %d: ", i, j);
      scanf("%d", &mat[i][j]);
    }
    printf("\n");
  }

  // Imprimindo a matriz de custos
  printf("\nMatriz de custos:\n");
  for (int i = 0; i < num_cidades; i ++) {
    for (int j = 0; j < num_cidades; j ++) {
      printf("%.2d ", mat[i][j]);
    }
    printf("\n");
  }

  // Quantidade de cidades que serão visitadas
  printf("\nDigite quantas cidades serao visitadas: ");
  scanf("%d", &visit_cidades);

  // Criando um vetor para alocar o itinerário
  itinerario = (int *)malloc(visit_cidades*sizeof(int));
  // Preenchendo o vetor
  for (int i = 0; i < visit_cidades; i ++) {
    printf("Digite a %da cidade do itinerario (0, %d): ", i + 1, num_cidades - 1);
    scanf("%d", &itinerario[i]);
  }
  // Imprimindo o itinerário
  printf("\nO itinerario sera: ");
  for (int i = 0; i < visit_cidades; i ++) {
    if (i == visit_cidades - 1) {
      printf("%d\n", itinerario[i]);
    }
    else {
      printf("%d, ", itinerario[i]);
    }
  }

  // Calculando o preço do itinerário
  custo = custoCidades(itinerario, visit_cidades, mat);
  printf("O custo total do itinerario sera: %d", custo);

  // Liberando memória reservada aos vetores e matriz
  free(itinerario);
  free(mat);
  free(vetor);

  return 0;
}
