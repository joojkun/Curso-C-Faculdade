#include <stdio.h>
#include <stdbool.h>
/* Apresentar os n primeiros números primos a partir de um valor inicial k.
Os valores de n e k são fornecidos pelo usuário - você deverá verificar se eles
são positivos. */

int main(){
  // Valores que serão dados pelo usuário
  int valor_inicial; // Valor de partida
  int sequencia; // Valor da sequência de números
  // Verifica se um número é primo
  bool primo_ver = true;

  // Lendo os valores
  printf("Digite o valor de partida: "); // Partida
  scanf("%d", &valor_inicial);
  printf("Digite a quantidade de valores que serao lidos: "); // Tamanho seq.
  scanf("%d", &sequencia);

  // Verificando se os números digitados são positivos
  while (valor_inicial < 0 || sequencia < 0){
    // Caso o número de partida seja negativo
    if (valor_inicial < 0){
      // Recebendo o valor novamente
      printf("O valor de partida nao pode ser negativo, digite denovo: ");
      scanf("%d", &valor_inicial);
    }
    // Caso o valor da sequência seja negativo
    if (sequencia < 0){
      // Recebendo o valor novamente
      printf("O valor da sequencia nao pode ser negativo, digite denovo: ");
      scanf("%d", &sequencia);
    }
  }

  // Valores primos na sequência digitada
  for (int cont = valor_inicial; cont <= (valor_inicial + sequencia); cont++){
    // Caso o número seja 1
    if (cont == 1){
      continue;
    }
    // Verificando se o valor é primo
    for (int i = 2; i < cont; i++){
      // Caso o valor não seja primo
      if (cont % i == 0 && cont != i){
        primo_ver = false;
        break;
      }
    }
    // Caso o número seja primo, o mesmo será impresso
    if (primo_ver){
      printf("%d\n", cont);
    }
    // Resetando o verificador
    primo_ver = true;
  }
  return 0;
}
