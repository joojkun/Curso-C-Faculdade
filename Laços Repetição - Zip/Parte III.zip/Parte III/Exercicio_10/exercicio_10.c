#include <stdio.h>
#include <stdbool.h>
/* Faça um programa que calcule o menor número divisível por cada um dos números
de 1 a 20. Ex: 2520 é o menor número que pode ser dividido por cada um dos
números de 1 a 10, sem sobrar resto. */
/* O.B.S = O programa demora bastante para encontrar o resultado
 (no caso, 232792560). Não sei se era para demorar tanto assim, mas não consegui
 achar um jeito de deixar o loop muito mais rápido de uma forma justa.
 Sem que eu tenha que iniciar a contagem já em um número bem alto por exempo.*/

int main(){
  // Número que será divido pelos números de 1 a 20
  int divisor = 1;
  // Variável que verifica se um número é divisivel por outro número
  bool ver_div = true;

  // Laço de repetição que irá testar as divisões
  while(true){
    // Verificando se o número é divisível pelos números de 1 a 20
    for (int i = 1; i <= 20; i ++){
      // Caso não seja divisível por um dos números o loop é interrompido
      if (divisor % i != 0){
        ver_div = false;
        break;
      }
    }
    // Caso o programa tenha achado o número divisivel por toda a sequência
    if (ver_div){
      printf("O menor numero divisivel por todos os numeros de 1 a 20 e %d\n",
             divisor);
      // Encerrando o loop
      break;
    }
    // Aumentando o divisor
    divisor ++;
    // Resetando o verificador
    ver_div = true;
  }
  return 0;
}
