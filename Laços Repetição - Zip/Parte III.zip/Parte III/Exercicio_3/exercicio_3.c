#include <stdio.h>
/* Dado n inteiro e maior que zero (fornecido pelo usuário), fazer um programa
para imprimir o gráfico da função x2+ x + 1 para x=-n até n. O programa deve
imprimir o gráfico rotacionado de 90o usando como ordenadas o eixo horizontal
e como abscissas o eixo vertical. */

int main(){
  // Valor que será digitado pelo usuário
  int valor_lido;
  // Imagem da função, valores do domínio e modulo das imagens
  int imagem, dominio_ponto, modulo_img;

  // Recebendo o valor do usuário
  printf("Digite um valor inteiro e maior do que zero: ");
  scanf("%d", &valor_lido);
  // O valor digitado deve ser positivo
  while (valor_lido <= 0){
    printf("O valor digitado deve ser positivo. Digite novamente: ");
    scanf("%d", &valor_lido);
  }
  // Oposto do valor, onde irá começar o conjunto domínio da função
  dominio_ponto = valor_lido - valor_lido*2;

  // Imprimindo o gráfico da função
  for (dominio_ponto; dominio_ponto <= valor_lido; dominio_ponto++){
    // Calculo da imagem da função
    imagem = (dominio_ponto*dominio_ponto) + dominio_ponto + 1;
    // Espaço para alinhar os valores
    if (dominio_ponto >= 0){
      printf(" ");
    }
    // Ponto do domínio
    printf("%d", dominio_ponto);
    // Módulo da imagem
    if (dominio_ponto < 0){
      modulo_img = dominio_ponto + dominio_ponto*2;
    }
    else{
      modulo_img = dominio_ponto;
    }
    // Pontos da função
    for (int pontos = 1; pontos <= imagem; pontos++){
      printf(" .");
    }
    // Final dos pontos
    printf("*\n");
  }
  return 0;
}
