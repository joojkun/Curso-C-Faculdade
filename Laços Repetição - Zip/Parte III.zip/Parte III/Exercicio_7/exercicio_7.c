#include <stdio.h>
/* Construa um programa que leia um número n natural e verifica se ele é
triangular ou não. Dizemos que um número natural é triangular se ele é produto
de três números naturais consecutivos. Exemplo: 120 é triangular, pois
4 x 5 x 6 = 120. */

int main(){
  // Valor que será lido
  int valor_lido;
  // Produto das multiplicações
  int produto;

  // Lendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);

  // Laço que irá verificar os produtos de valores naturais consecutivos
  for (int cont = 0; cont < valor_lido; cont++){
    // Valor será multiplicado
    produto = cont;

    /* Caso o valor atual esteja a dois ou menos valores do valor digitado,
     a sequência será quebrada, pois um valor triângular precisa de 3 valores
    somados */
    if (valor_lido - cont < 3){
      printf("O numero %d nao e triangular.\n", valor_lido);
      break;
    }
    for (int i = 1; i <= 2; i++){
      produto = produto * (cont + i);
    }
    // Verificando se o valor da multiplicação é igual ao valor digitado
    if (produto == valor_lido){
      // Imprimindo a expressão mostrando que o valor é triangular
      for (int i = 0; i <= 2; i++){
        if (i == 2){
          printf("%d = ", cont + i);
        }
        else{
          printf("%d X ", cont + i);
        }
      }
      // Imprimindo o resultado da expressão
      printf("%d\n", produto);
      break;
    }
  }
  return 0;
}
