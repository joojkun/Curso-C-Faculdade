#include <stdio.h>
/* Dados t números inteiros positivos (t fornecido pelo usuário), calcular a
 soma dos que são primos. */

int main(){
  // Valor t que será lido e valores da sequência t
  int valor_lido, num_seq;
  // Soma dos valores primos da sequência t
  int soma_primos = 0;

  // Lendo o valor
  printf("Digite um valor (tamanho da sequencia): ");
  scanf("%d", &valor_lido);

  for (int cont = 1; cont <= valor_lido; cont++){
    // Lendo o valor
    printf("Digite um valor: ");
    scanf("%d", &num_seq);
    // Caso o valor seja igual a 1
    if (num_seq == 1){
      continue;
    }
    // Adicionado o número na soma dos primos
    soma_primos += num_seq;
    // Verificando se o número é primo
    for (int i = 2; i < num_seq; i++){
      // Caso não seja primo, será removido da soma de primos
      if (num_seq % i == 0){
        soma_primos -= num_seq;
        break;
      }
    }
  }
  // Imprimindo o resultado
  printf("Soma dos primos: %d", soma_primos);
  return 0;
}
