#include <stdio.h>
/* Dado n inteiro e maior que zero (fornecido pelo usuário), fazer um programa
para imprimir uma tabela com os valores
de i*j para i= 1, 2, . . . , n e j=1, 2, . . . , n, da seguinte forma
(supondo n=5):
1 1
2 2 4
3 3 6 9
4 4 8 12 16
5 5 10 15 20 25

1 2 3 4 5 // dica: imprima essa linha antes das repetições
encaixadas.
*/

int main(){
  // Valor que será lido
  int valor_lido;

  // Recebendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);

  // Imprimindo a sequência n na tela
  for (int n = 1; n <= valor_lido; n++){
    printf("%d ", n);
  }
  // Quebra de linha antes de imprimir a próxima sequência
  printf("\n");

  // Imprimindo a próxima sequência
  for (int cont = 1; cont <= valor_lido; cont++){
    // Valor inicial da linha
    printf("%d ", cont);
    // Próximos valores da linha
    for (int cont2 = 1; cont2 <= cont; cont2++){
      printf("%d ", cont * cont2);
    }
    // Quebra para a próxima linha
    printf("\n");
  }
  return 0;
}
