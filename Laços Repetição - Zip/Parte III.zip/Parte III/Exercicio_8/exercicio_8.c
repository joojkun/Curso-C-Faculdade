#include <stdio.h>
#include <stdbool.h>
/* Faça um programa que verifica se os dígitos de um valor n fornecido pelo
 usuário são todos iguais entre si. */

int main(){
  // Valor que será lido
  int valor_lido;
  // Digito atual e anterior
  int digito_x, digito_y;

  // Lendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);
  digito_x = valor_lido % 10;

  // Loop que verifica os dígitos de um número
  while(true){
    // Dígito do número
    digito_x %= 10;
    // Caso o dígito atual seja diferente do próximo digito
    if (digito_x != valor_lido % 10){
      printf("Os valores sao diferentes entre si\n");
      break;
    }
    // Caso seja igual, o dígito atual será eliminado do número
    else{
      valor_lido /= 10;
      // Caso os dígitos tenham acabo
      if (valor_lido == 0){
        printf("Os valores sao todos iguais entre si.\n");
        break;
      }
    }
  }
  return 0;
}
