#include <stdio.h>
/* Sabe-se que um número da forma n³ é igual à soma de n ímpares consecutivos,
faça um programa que o usuário forneça o valor de m, e o programa determine os
ímpares consecutivos cuja soma é igual a n³ para para n assumindo valores de 1
a m. No exemplo abaixo m = 4.*/

int main(){
  // Valor que será digitado pelo usuário
  int valor_lido;
  // Cubo do valor digitado
  int cubo_valor_lido;
  // Soma dos números ímpares encontrados
  int soma_impares = 0;

  // Lendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);
  // Calculando o cubo do valor lido
  cubo_valor_lido = valor_lido * valor_lido * valor_lido;

  // Caso o cubo de um número seja igual a ele mesmo
  if (valor_lido == cubo_valor_lido){
    printf("%d^3 = %d\n", valor_lido, valor_lido);
  }
  // Caso contrário
  else{
    // Lendo os números ímpares até o número digitado
    for (int cont = 1; cont < cubo_valor_lido; cont += 2){
      // Valor que será somado com os próximos ímpares da sequência
      soma_impares = cont;
      // Laço para somar os valores ímpares
      for (int cont_soma = 1; cont_soma < valor_lido; cont_soma++){
        // Soma dos ímpares
        soma_impares = soma_impares + (cont + (cont_soma*2));
      }
      /* Caso o valor da soma da sequência de valores ímpares seja igual
       ao cubo do valor digitado */
      if (soma_impares == cubo_valor_lido){
        // Imprimindo a operação matemática com a soma dos números
        printf("%d^3 = ", valor_lido);
        // Laço para adicionar os termos da expressão
        for (int i = 1; i <= valor_lido; i++){
          /* Caso já esteja no último termo da expressão, não haverá
           outro sinal de soma */
          if (i == valor_lido){
            printf("%d ", cont);
          }
          /* Enquanto ainda não estiver no ultimo termo da expressão,
           terá sinal de soma */
          else{
            printf("%d + ", cont);
          }
          // Termos da expressão
          cont += 2;
        }
        // Resultado da expressão, ou seja, a soma dos valores ímpares
        printf("= %d\n", soma_impares);
        // Encerrando o Loop, pois o resultado desejado já foi encontrado
        break;
      }
    }
  }
  return 0;
}
