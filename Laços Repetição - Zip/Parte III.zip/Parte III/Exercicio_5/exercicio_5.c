#include <stdio.h>
#include <stdbool.h>
/* Construa um programa que leia um número n e, em seguida, leia uma sequência
de n números inteiros e verifique se ela está ordenada de forma crescente.*/

int main(){
  // Número de valores que serão lidos
  int num_valores;
  // Novos valores que serão recebidos
  int n1 = 0, n2 = 0;
  // Verificador de ordem crescente
  bool ordem_ver = true;

  // Recebendo o número de valores
  printf("Digite um valor: ");
  scanf("%d", &num_valores);

  // Lista de valores que serão digitados
  for (int cont = 1; cont <= num_valores; cont++){
    // Recebendo um valor
    printf("Digite um numero: ");
    scanf("%d", &n1);
    /* Se houver um valor anterior, será verificado se o novo valor
     é maior que o antigo */
    if (cont > 1){
      // Caso não seja maior
      if (n1 < n2){
        ordem_ver = false;
      }
    }
    // Aumentado o contador depois de um valor ter sido digitado
    cont++;
    /* Caso o número de valores digitados tenha chegado no limite
     o laço é interrompido */
    if (cont > num_valores){
      break;
    }
    // Recebendo o próximo valor
    printf("Digite um numero: ");
    scanf("%d", &n2);
    // Comparando com o valor anterior
    // Caso o novo valor seja menor que o anterior, a sequência não é crescente
    if (n2 < n1){
      ordem_ver = false;
    }
  }

  // Caso a sequência seja crescente
  if (ordem_ver){
    printf("sim\n");
  }
  // Caso a sequência não seja crescente
  else{
    printf("nao\n");
  }
  return 0;
}
