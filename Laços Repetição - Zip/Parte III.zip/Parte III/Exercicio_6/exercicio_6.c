#include <stdio.h>
#include <stdbool.h>
/* Modifique o programa anterior para verificar se a sequência está (a) ordenada
de forma crescente, (b) ordenada de forma decrescente ou (c) desordenada.*/

int main(){
  // Número de valores que serão lidos
  int num_valores;
  // Novos valores que serão recebidos
  int n1 = 0, n2 = 0;
  // Verificador de ordem crescente, decrescnete ou desordenada
  bool ordem_cre = false, ordem_dec = false;

  // Recebendo o número de valores
  printf("Digite um valor: ");
  scanf("%d", &num_valores);

  // Lista de valores que serão digitados
  for (int cont = 1; cont <= num_valores; cont++){
    // Recebendo um valor
    printf("Digite um numero: ");
    scanf("%d", &n1);
    /* Se houver um valor anterior, será verificado se o novo valor
     é maior que o antigo */
    if (cont > 1){
      // Ordem Decrescente
      if (n1 < n2){
        ordem_dec = true;
      }
      // Ordem Crescente
      else if (n1 >= n2){
        ordem_cre = true;
      }
    }
    // Aumentado o contador depois de um valor ter sido digitado
    cont++;
    /* Caso o número de valores digitados tenha chegado no limite
     o laço é interrompido */
    if (cont > num_valores){
      break;
    }
    // Recebendo o próximo valor
    printf("Digite um numero: ");
    scanf("%d", &n2);
    // Caso o novo valor seja menor que o anterior, a sequência não é crescente
    // Decrescente
    if (n2 < n1){
      ordem_dec = true;
    }
    // Crescente
    else if (n2 >= n1){
      ordem_cre = true;
    }
  }

  // Caso a sequência seja crescente
  if (ordem_cre && ordem_dec != true){
    printf("Crescente\n");
  }
  // Caso a sequência seja decrescente
  else if (ordem_dec && ordem_cre != true){
    printf("Decrescente\n");
  }
  // Caso a sequência seja desordenada
  else{
    printf("Desordenada\n");
  }
  return 0;
}
