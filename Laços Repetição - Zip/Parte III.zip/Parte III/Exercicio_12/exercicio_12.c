#include <stdio.h>
/* Faça um programa que leia dois valores do teclado, n1 e n2, e usando o método
 da fatoração, calcule o Mínimo Múltiplo Comun (MMC) de n1 e n2. */

int main(){
  // Valores que serão lidos
  int valor_1, valor_2;
  // Multiplos dos números e valor do MMC
  int multiplo = 2, mmc_valor = 1;

  // Lendo os valores
  printf("Digite um valor: ");
  scanf("%d", &valor_1); // Primeiro valor
  printf("Digite outro valor: ");
  scanf("%d", &valor_2); // Segundo valor

  // Calculando o M.M.C.
  while(valor_1 != 1 || valor_2 != 1){
    // Caso o multiplo seja divisivel por ambos os valores
    if (valor_1 % multiplo == 0 && valor_2 % multiplo == 0){
      valor_1 /= multiplo;
      valor_2 /= multiplo;
      mmc_valor *= multiplo;
    }
    // Caso o multiplo seja divisivel apenas por um dos valores
    else if (valor_1 % multiplo == 0 || valor_2 % multiplo == 0){
      // Caso seja divisivel pelo primeiro valor
      if (valor_1 % multiplo == 0){
        valor_1 /= multiplo;
        mmc_valor *= multiplo;
      }
      // Caso seja divisivel pelo segundo valor
      if (valor_2 % multiplo == 0){
        valor_2 /= multiplo;
        mmc_valor *= multiplo;
      }
    }
    // Caso o multiplo não seja divisível por nenhum dos valores
    else {
      multiplo ++;
    }
  }
  // Imprimindo o resultado
  printf("O valor do M.M.C. e igual a %d\n", mmc_valor);
  return 0;
}
