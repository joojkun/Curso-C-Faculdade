#include <stdio.h>
/* Faça um programa que dados n e m inteiros e maiores que zero (fornecidos pelo
usuário), imprima uma tabela com os valores de i*j para i= 1, 2,..., n e j=1, 2,
..., m, da seguinte forma (supondo n=3 e m=5) */

int main() {
  // Número de fileiras e colunas que serão recebidas pelo usuário
  int fileiras, colunas;
  // Números que serão impressos na tabela
  int valor_tabela = 1;

  // Recebendo o número de fileiras e colunas
  printf("Digite um valor (fileiras): "); // Fileiras
  scanf("%d", &fileiras);
  printf("Digite outro valor (colunas): "); // Colunas
  scanf("%d", &colunas);

  // Laço de repetição referente às fileiras
  for (int cont_fileira = 1; cont_fileira <= fileiras; cont_fileira++){
    // Resetando os valores que serão impressos na tabela
    valor_tabela = cont_fileira;
    // Laço de repetição referente às colunas
    for (int cont_colunas = 1; cont_colunas <= colunas; cont_colunas++){
      // Caso o número possua apenas um dígito (Só pra ficar bonito mesmo)
      if (valor_tabela < 10){
        printf("%.2d ", valor_tabela);
      }
      // Caso o número já possua dois dígitos
      else{
        printf("%d ", valor_tabela);
      }
      // Aumentando os valores que aparecerão na tabela
      valor_tabela += cont_fileira;
    }
    // Quebrando a linha entre as fileiras da tabela
    printf("\n");
  }
  return 0;
}
