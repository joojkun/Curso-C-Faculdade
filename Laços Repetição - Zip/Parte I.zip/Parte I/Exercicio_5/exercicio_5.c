#include <stdio.h>
/*Construa um programa que leia um número inteiro positivo n, verifique e
informe se o mesmo é perfeito ou não. Dizemos que n é perfeito se a soma de
todos os divisores positivos próprios - excluindo ele mesmo - é igual a n.
Exemplo: 28 é perfeito, pois 1 + 2 + 4 + 7 + 14 = 28*/

int main(){
  // Valor que será lido
  int valor_lido;
  // Soma dos divisores
  int soma_divisores = 0;

  // Lendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);

  // Laço de repetição com intervalo de 1 até o número digitado
  for (int contador = 1; contador < valor_lido; contador++){
    // Verificando se o contador é um divisível próprio de n
    if (valor_lido % contador == 0){
      // Somando os divisores do valor
      soma_divisores += contador;
    }
  }

  // Verificando se o número é perfeito
  // Caso seja um valor perfeito
  if (soma_divisores == valor_lido){
    printf("O valor %d eh um numero perfeito!\n", valor_lido);
  }
  // Caso não seja um valor perfeito
  else{
    printf("O valor %d nao eh um numero perfeito!\n", valor_lido);
  }
  return 0;
}
