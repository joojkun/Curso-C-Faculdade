#include <stdio.h>
/*A seguinte sequência de números 0 1 1 2 3 5 8 13 21... é conhecida como série
de Fibonacci. Nessa sequência, cada número, depois dos 2 primeiros, é igual à
soma dos 2 anteriores. Escreva um algoritmo que leia um inteiro n e mostre os n
primeiros números dessa série.
Exemplo de Entrada: 6
Exemplo de Saída: 0 1 1 2 3 5
*/
int main(){
  // Valor que será lido
  int valor_lido;
  // Número atual da sequência
  int num_atual = 1, num_anterior = 0;

  // Lendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);
  // Primeiro valor da sequência
  printf("0\n");
  // Imprimindo o resto da sequência na tela
  for (int contador = 2; contador <= valor_lido; contador ++){
    // Valor atual da sequência
    printf("%d\n", num_atual);
    contador ++;
    // Caso o número de valores máximo já tenha sido alcançado
    if (contador >= valor_lido && valor_lido % 2 == 0){
      break;
    }
    // Próximo valor da sequência
    printf("%d\n", num_atual + num_anterior);
    // Obtendo os próximos valores
    num_anterior += num_atual;
    num_atual += num_anterior;
  }
  return 0;
}
