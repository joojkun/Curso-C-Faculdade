#include <stdio.h>
/*Faça um programa para ler um valor n. Calcular e imprimir seu respectivo
fatorial. Até qual valor de n seu programa apresenta resultados consistentes?

Resposta: O programa apresenta resultados consistentes até o fatorial de 12.*/
int main(){
  // Valor que será digitado pelo usuário
  int valor_lido;
  // Resultado do fatorial
  int fatorial = 1;

  // Lendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);

  // Calculando seu fatorial
  for (int contador = 1; contador <= valor_lido; contador++){
    fatorial *= contador;
  }
  // Imprimindo o resultado na tela
  printf("%d! = %d\n", valor_lido, fatorial);
  return 0;
}
