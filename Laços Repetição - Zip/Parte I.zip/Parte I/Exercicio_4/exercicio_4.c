#include <stdio.h>
/*. Leia um valor inteiro n, que representa o número de casos de teste que vem
a seguir. Cada caso de teste consiste de 3 valores reais. Faça um programa que
leia os 3 valores de cada caso de teste e apresente a média ponderada para cada
caso, sendo que o primeiro valor tem peso 2, o segundo valor tem peso 3 e o
terceiro valor tem peso 5.*/

int main(){
  // Número de casos de teste
  int casos_de_teste;
  // Valores reais do caso de teste
  float valor_1, valor_2, valor_3;
  // Média ponderada de cada caso de teste
  float media_ponderada;

  // Lendo o número de casos de teste
  printf("Digite o numero de casos de teste que serao realisados: ");
  scanf("%d", &casos_de_teste);

  // Relizando os casos de teste
  for (int contador = 1; contador <= casos_de_teste; contador++){
    // Lendo os valores do caso de teste
    printf("Digite um valor: "); // Primeiro valor
    scanf("%f", &valor_1);
    printf("Digite mais um valor: "); // Segundo valor
    scanf("%f", &valor_2);
    printf("Digite outro valor: "); // Terceiro valor
    scanf("%f", &valor_3);

    // Calculando a média ponderada
    media_ponderada = ((valor_1 * 2) + (valor_2 * 3) + (valor_3 * 5))/10;
    // Imprimindo o resultado
    printf("A media ponderada dos valores lidos e: %.2f\n\n", media_ponderada);
  }
  return 0;
}
