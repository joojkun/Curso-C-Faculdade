#include <stdio.h>
/*O número 3025 possui a seguinte característica: 30 + 25 = 55 -> 55 X 55 = 3025.
Fazer um programa para obter todos os números de 4 algarismos com a mesma
característica do número 3025*/
int main(){
  // Soma das dezenas do número
  int soma_dezenas;
  // Realizando o teste em todos os números de 4 algarismos
  for (int contador = 1000; contador <= 9999; contador++){
    // Obtendo os algarismos do número
    soma_dezenas = contador / 100 + contador % 100;

    // Verificando se o número possui a mesma característica de 3025
    if (soma_dezenas * soma_dezenas == contador){
      printf("O numero %d possui a mesma caracteristica de 3025.\n", contador);
    }
  }
  return 0;
}
