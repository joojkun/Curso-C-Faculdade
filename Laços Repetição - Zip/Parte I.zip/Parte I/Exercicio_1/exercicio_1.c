#include <stdio.h>
// Leia um valor inteiro n e mostre na tela a sua tabuada (n x 1 até n x 10)

int main(){
  // Valor que será lido
  int valor_lido;
  // Valor multiplicado na tuabada
  int valor_multiplicado;

  // Lendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);

  // Imprimindo a tábuada do valor lido
  for(int counter = 1; counter <= 10; counter++){
    // Resultado da multiplicação
    valor_multiplicado = counter * valor_lido;
    printf("%d X %d = %d\n", valor_lido, counter, valor_multiplicado);
  }
  return 0;
}
