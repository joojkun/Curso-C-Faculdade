#include <stdio.h>
/*Leia um valor inteiro n. Apresente todos os números de 1 a 100 que divididos
por n dão resto igual a 2.*/

int main(){
  // Valor N que será lido
  int valor_lido;

  // Lendo valor que será usado
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);

  // Laço de repetição com números de 1 a 100
  for (int counter = 1; counter <= 100; counter++){
    // Verificando se o resto da divisão é 2
    if (valor_lido % counter == 2){
      printf("%d\n", counter);
    }
  }
  return 0;
}
