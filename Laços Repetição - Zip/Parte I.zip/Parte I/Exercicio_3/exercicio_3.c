#include <stdio.h>
/*Leia 2 valores inteiros x e y (suponha que x > y). A seguir, calcule e mostre
quantos números ímpares existem entre eles.*/

int main(){
  // Valores que serão lidos
  int valor_x, valor_y;
  // Contador do Laço de repetição e dos números impares
  int contador, contador_num_impar = 0;

  // Lendo os valores
  printf("Digite um valor: ");
  scanf("%d", &valor_x); // Valor X
  printf("Digite mais um valor, porem, menor do que o valor anterior: ");
  scanf("%d", &valor_y); // Valor Y

  // O Programa não irá aceitar um valor Y maior que o valor X
  if (valor_x <= valor_y){
    printf("O primeiro valor deve ser maior do que o segundo valor!\n");
  }
  // Caso o valor X seja o maior
  else{
    // Laço de repetição para mostrar os valores impares entre X e Y
    contador = valor_y + 1;
    for (contador; contador < valor_x; contador++){
      // Verificando se o valor é impar
      if (contador % 2 != 0){
        contador_num_impar += 1;
      }
    }
    // Imprimindo a quantidade de números impares
    printf("Entre %d e %d existem %d valores impares!\n",
           valor_x, valor_y, contador_num_impar);
  }
  return 0;
}
