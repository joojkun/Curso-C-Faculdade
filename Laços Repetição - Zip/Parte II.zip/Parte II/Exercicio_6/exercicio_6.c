#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/*Faça um programa que sorteie um número aleatório entre 1 e 500 e então peça ao
usuário para adivinhar este valor. O programa deverá indicar a cada tentativa do
usuário se ela é maior ou menor que o número mágico e contar o número de
tentativas. Quando o usuário conseguir acertar o número, o programa deverá
classificar o usuário como: (a) de 1 a 3 tentativas: \o/; (b) d 4 a 6 tentativas:
:-D; (c) de 7 a 10 tentativas: :-) e (d) Mais que 10 tentativas: :-\
 */
int main() {
  // Valor que será digitado pelo usuário
  int valor_lido;
  // Contador de quantos números o usuário digitou
  int contador_tentativas = 0;
  // Inicializando a biblioteca Rand
  srand(time(NULL));
  // Números que será sorteados
  int num_random;

  // Gerando o número aleatório
  num_random = (rand() % 498) + 1;

  // Recebendo o número digitado pelo usuário
  printf("Digite um valor entre 1 e 500: ");
  scanf("%d", &valor_lido);

  /* Enquanto o valor digitado for diferente do valor gerado, o usuário irá
  digitar novos valores*/
  while (num_random != valor_lido){
    // Aumentando o contador de tentativas
    contador_tentativas += 1;
    // Resposta Errada
    // Caso o número digitado seja maior que o número gerado
    if (valor_lido > num_random){
      printf("Resposta errada, o valor digitado eh maior que o valor certo!\n"
             "Numero de tentativas: %d\n", contador_tentativas);
    }
    // Caso o número digitado seja menor que o número gerado
    else if (valor_lido < num_random){
      printf("Resposta errada, o valor digitado eh menor que o valor certo!\n"
             "Numero de tentativas: %d\n", contador_tentativas);
    }
    // Recebendo o número digitado pelo usuário
    printf("Digite um valor entre 1 e 500: ");
    scanf("%d", &valor_lido);
  }

  // Caso o usuário acerte a resposta
  // Classificando o usuário de acordo com o número de tentativas
  contador_tentativas += 1;
  // 1 a 3 tentativas
  if (contador_tentativas <= 3){
    printf("Parabens, voce acertou a resposta! \o/\n"
         "Numero de tentativas: %d", contador_tentativas);
  }
  // 4 a 6 tentativas
  else if (contador_tentativas >= 4 && contador_tentativas <= 6){
    printf("Parabens, voce acertou a resposta! :-D\n"
         "Numero de tentativas: %d", contador_tentativas);
  }
  // 7 a 10 tentativas
  else if (contador_tentativas >= 7 && contador_tentativas <= 10){
    printf("Parabens, voce acertou a resposta! :-)\n"
         "Numero de tentativas: %d", contador_tentativas);
  }
  // Mais do que 10 tentativas
  else{
    printf("Parabens, voce acertou a resposta. :-/ \n"
         "Numero de tentativas: %d", contador_tentativas);
  }
  return 0;
}
