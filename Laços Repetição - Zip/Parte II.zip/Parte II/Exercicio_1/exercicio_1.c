#include <stdio.h>
/*Escreva um programa que leia números digitados pelo usuário até que este digite
um valor negativo. Neste momento,o programa deverá encerrar a entrada de dados
e apresentar o maior valor entre todos os digitados.*/

int main() {
  // Valor que será lido
  float valor_lido;
  float maior_valor;

  // Recebendo o valor
  printf("Digite um valor: ");
  scanf("%f", &valor_lido);

  // Dando o valor digitado como o maior valor até agora
  maior_valor = valor_lido;

  // Caso o valor seja negativo, irá iniciar um laço de repetição
  while(valor_lido >= 0){
    // Recebendo o valor
    printf("Digite um valor: ");
    scanf("%f", &valor_lido);

    // Verificando se foi o maior valor digitado
    if (valor_lido > maior_valor){
      // Gerando o novo maior valor
      maior_valor = valor_lido;
    }
  }
  // Apresentando o maior valor digitado
  printf("O maior valor digitado foi: %.1f", maior_valor);

  return 0;
}
