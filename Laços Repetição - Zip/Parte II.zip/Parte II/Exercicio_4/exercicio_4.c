#include <stdio.h>
#include <stdbool.h>
/*Faça um programa que leia dois valores do teclado, n1 e n2, e calcule o Mínimo
 Múltiplo Comun (MMC) de n1 e n2.*/

int main() {
  // Valores que serão lidos
  int n1, n1_aux, n2, n2_aux;
  int multiplos = 1;
  // Valor que será testado como multiplo
  int i = 2;

  // Lendo os valores n1 e n2
  printf("Digite o primeiro valor: ");
  scanf("%d", &n1);
  // Segundo valor
  printf("Digite o segundo valor: ");
  scanf("%d", &n2);

  n1_aux = n1;
  n2_aux = n2;
  // Enquanto um dos números forem diferentes de zero
  while (n1_aux != 1 || n2_aux != 1){
    // Verificando se o número atual é multiplo de n1
    // Caso seja multiplo de n1 e n2
    if (n1_aux % i == 0 && n2_aux % i == 0){
      n1_aux /= i;
      n2_aux /= i;
      multiplos *= i;
    }
    // Caso seja multiplo apenas de n1
    else if(n1_aux % i == 0){
      n1_aux /= i;
      multiplos *= i;
    }
    // Caso seja multiplo apenas de n2
    else if(n2_aux % i == 0){
      n2_aux /= i;
      multiplos *= i;
    }
    else{
      i++;
    }
  }
  // Imprimindo o resultado do M.M.C.
  printf("O M.M.C. de %d e %d e: %d\n", n1, n2, multiplos);
  return 0;
}
