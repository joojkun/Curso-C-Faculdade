#include <stdio.h>
/*Escreva um programa que repita a leitura de uma senha até que ela seja válida.
Para cada leitura de senha incorreta informada, escrever a mensagem
"Senha Invalida". Quando a senha for informada corretamente deve ser impressa
amensagem "Acesso Permitido" e o algoritmo encerrado.
Considere que a senha correta é o valor 2002.*/

int main() {
  // Valor da senha que será lido
  int senha_digitada;
  // Valor correto da senha
  int senha_correta = 2002;

  // Recebendo a senha digitada pelo usuário
  printf("Informe a senha: ");
  scanf("%d", &senha_digitada);

  /* Enquanto a senha estiver errada, a máquina pedirá para o usuário digitá-la
  novamente*/
  while (senha_correta != senha_digitada){
    // Senha incorreta
    printf("Senha Invalida!\n");
    // Recebendo a senha digitada pelo usuário
    printf("Informe a senha novamente: ");
    scanf("%d", &senha_digitada);

  }

  // Após o usuário haver digitado a senha correta
  printf("Acesso Permitido!\n");

  return 0;
}
