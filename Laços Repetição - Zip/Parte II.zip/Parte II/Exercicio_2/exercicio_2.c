#include <stdio.h>
/*Leia um conjunto de valores inteiros (até que o -1000 seja digitado).
Em seguida, mostre quantos destes valores digitados foram positivos. Na próxima
linha, deve-se mostrar a média de todos os valores positivos digitados,
com um dígito após o ponto decimal.*/

int main() {
  // Valor que será lido
  float valor_lido;
  // Quantidade de números positivos digitados
  float numeros_positivos;
  // Média dos valores positivos digitados
  float media_num_positivo = 0.0;

  // Lendo um valor
  printf("Digite um valor: ");
  scanf("%f", &valor_lido);

  // Laço de repetição que será quebrado quando o número -1000 for digitado
  while (valor_lido != -1000){
    // Verificando se o número digitado foi positivo
    if (valor_lido > 0){
      // Número de valores positivos digitados
      numeros_positivos += 1;
      // Somando o valor na média de números positivos
      media_num_positivo += valor_lido;
    }
    // Lendo um valor
    printf("Digite um valor: ");
    scanf("%f", &valor_lido);
  }

  // Após o valor -1000 ser digitado
  // Quantidade de números positivos digitados
  printf("A quantidade de números positivos digitados foi: %.f\n",
         numeros_positivos);
  // Média dos números positivos digitados
  media_num_positivo = media_num_positivo / numeros_positivos;
  // Imprimindo a média
  printf("A média dos números positivos digitados é: %.1f\n",
         media_num_positivo);
  return 0;
}
