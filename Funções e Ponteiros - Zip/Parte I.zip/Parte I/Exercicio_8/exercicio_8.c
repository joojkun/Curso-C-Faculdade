#include <stdio.h>

void determinaValores(int n) {
  for (int a = 1; a <= (n - 2); a ++) {
    for (int b = 1; b <= 9; b ++) {
      for (int c = 1; c <= 9; c++) {
        if (a + b + c == n) {
          printf("%d + %d + %d = %d\n", a, b, c, a + b + c);
        }
        else if (a + b + c > n) {
          break;
        }
      }
    }
  }
}

int main () {
  // Valor que será lido
  int valor_lido;

  // Lendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);
  determinaValores(valor_lido);
  return 0;
}
