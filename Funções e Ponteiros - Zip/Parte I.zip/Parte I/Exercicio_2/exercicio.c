#include <stdio.h>

int arredonda(float valor) {
  int var = (valor * 10);
  int valor_arredondado;

  // Caso o número va ser arredondado para cima
  if (var % 10 >= 5) {
    valor_arredondado = ((var - (var % 10)) / 10) + 1;
    return valor_arredondado;
  }
  // Caso seja arredondado para baixo
  else {
    // Para números negativos que serão arredondados para baixo
    if (var < 0 && - (var % 10) >= 5){
      valor_arredondado = ((var - (var % 10)) / 10) - 1; 
    }
    else {
      valor_arredondado = (var - (var % 10)) / 10; 
    }
    return valor_arredondado;
  }
}

int main(void) {
  // Valor que será lido
  float valor_lido;

  // Lendo o valor
  printf("Digite um valor decimal para ser arredondado: ");
  scanf("%f", &valor_lido);

  // Executando a função
  printf("Valor arredondado: %d",arredonda(valor_lido));
  
  return 0;
}