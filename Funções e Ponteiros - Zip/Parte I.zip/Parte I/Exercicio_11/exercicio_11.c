#include <stdio.h>
#include <math.h>
#include <stdbool.h>

int contDigitos(valor, digito) {
  int cont = 0;

  // Contando os dígitos
  while (valor != 0){
    if (valor % 10 == digito) {
      cont ++;
    }
    valor /= 10;
  }
  // Retornando o contador
  return cont;
}

int verPermutacao(valor_1, valor_2) {
  // Número de caracteres em valor_1
  int size_v1 = 0;
  // Copia valor_1 e valor_2
  int v1_copy = valor_1, v2_copy = valor_2;
  /* Quantas vezes o mesmo caractere aparece em valor_1 
   e quantas vezes aparece em valor_2 */
  int cont_char, soma_cont = 0, cont_v2 = 0;
  // Verificador de permutação
  int ver_permt = 0;

  // Contando o número de caractéres
  while (v1_copy != 0) {
    size_v1 ++;
    v1_copy /= 10;
  }
  v1_copy = valor_1;

  /*
    Verificando a presença de valor 1 em valor 2
     para cada caractere de valor_1
  */
  for (int i = 1; i <= size_v1; i++) {
    cont_char = contDigitos(valor_1, v1_copy % 10);
    soma_cont  += cont_char;
    // Verificando se o valor aparece no valor_2
    while (v2_copy != 0) { 
      // Caso o caractere apareça em valor_2
      if (v2_copy % 10 == v1_copy % 10) {
        cont_v2 ++;
      }
      v2_copy /= 10;
    }
    // Resetando valor da cópia de valor_2
    v2_copy = valor_2;
    // Passando para o próximo caractere
    v1_copy /= 10;
  }

  // Caso seja permutação
  if (soma_cont == cont_v2) {
    return 1;
  }
  // Caso não seja permutação
  else {
    return 0;
  }
}

int main() {
  // Valores que serão lidos
  // Número e dígitos
  int n, d;
  // Valores para a permutação
  int valor_1, valor_2;
  // Resultado permutação
  int prmt;

  // Lendo os valores
  printf("Digite um valor: ");
  scanf("%d", &n);
  printf("Digite um digito para ser procurado no valor: ");
  scanf("%d", &d);

  //Resultado
  printf("O digito aparece %d vezes no valor %d\n", 
  contDigitos(n, d), n);

  // Lendo valores (Permutação)
  printf("Digite um numero: ");
  scanf("%d", &valor_1);
  printf("Digite mais um numero: ");
  scanf("%d", &valor_2);

  // Resultado
  prmt = verPermutacao(valor_1, valor_2);
  // Caso seja permutação
  if (prmt == 1) {
    printf("O valor %d e permutacao de %d!", valor_1, valor_2);
  }
  else {
    
    printf("O valor %d nao e permutacao de %d!", valor_1, valor_2);
  }

  return 0;
}
