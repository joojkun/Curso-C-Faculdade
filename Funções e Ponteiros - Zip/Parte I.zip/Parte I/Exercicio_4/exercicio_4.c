#include <stdio.h>

int digitoVerficador(valor) {
  // Digito verificador
  int digito_ver;
  // Termos
  int t_1 = ((valor % 1000) / 100) * 1;
  int t_2 = ((valor % 100) / 10) * 2;
  int t_3 = (valor % 10) * 3;

  // Calculando resultado
  digito_ver  = ((t_1 + t_2 + t_3) % 11) % 10;

  return digito_ver;
}

int main() {
  // Valor que será lido
  int valor_lido;
  // Digito verificador
  int dv;

  // Lendo o valor
  printf("Digite um valor de 3 digitos: ");
  scanf("%d", &valor_lido);

  // Resultado
  dv = digitoVerficador(valor_lido);
  printf("Digito verificador: %d", dv);

  return 0;
}
