#include <stdio.h>

int verDigitos(int valor_1, int valor_2) {
  int cont_digitos = 0, ver_cont = 0;
  int valor_2_copia = valor_2;
  // Fatorando o primeiro valor
  while (valor_2_copia != 0) {
    valor_2_copia /= 10;
    cont_digitos ++;
  }
  // Verificando a igualdade dos dígitos
  for (int i = 1; i <= cont_digitos; i++) {
    if (valor_1 % 10 == valor_2 % 10){
      ver_cont ++;
      valor_1 /= 10;
      valor_2 /= 10;
    }
  }

  // Caso valor_2 pertença a valor_1
  if (cont_digitos == ver_cont){
    return 1;
  }
  // Caso valor_2 não pertença a valor_1
  else {
    return 0;
  }

}

void main() {
  // Valores que serão lidos
  int valor_1, valor_2;
  // Resultado da verificação
  int ver_result;

  // Lendo os valores
  printf("Digite um valor: ");
  scanf("%d", &valor_1);
  printf("Digite o valor que será procurado no primeiro valor: ");
  scanf("%d", &valor_2);

  // Resultado
  ver_result = verDigitos(valor_1, valor_2);
  if (ver_result == 1) {
    printf("%d faz parte dos ultimos digitos de %d.\nRetorno(%d)",
    valor_2, valor_1, ver_result);
  }
  else {
    printf("%d nao faz parte dos ultimos digitos de %d.\nRetorno(%d)",
    valor_2, valor_1, ver_result);
  }

}
