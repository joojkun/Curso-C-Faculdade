#include <stdio.h>

int divide(int *m, int *n, int d) {
  if (*m % d == 0 && *n % d == 0) {
    // Dividindo o primeiro valor
    *m /= d;
    // Dividindo o segundo valor
    *n /= d;
    return 1;
  }
  else if (*m % d == 0) {
    // Dividindo apenas o primeiro valor
    *m /= d;
    return 1;
  }
  else if (*n % d == 0) {
    // Dividindo apenas o segundo valor
    *n /= d;
    return 1;
  }
  else {
    return 0;
  }
}

int mmcCalculo (int m, int n) {
  int mmc = 1;
  int divisor = 2;
  int divisor_usdo = 0;

  while (m != 1 || n != 1) {
     if (divide(&m, &n, divisor) == 1) {
       mmc *= divisor; 
     }
     else {
       divisor ++;
     }
  }

  return mmc;

}

int main() {
  // Valores que serão lidos
  int valor_a, valor_b;
  // Quantos valores serão lidos
  int seq_value;
  int i = 1;
  int mmmc_atual = 0;

  // Lendo os valores
  printf("Digite quantos valores serao lidos: ");
  scanf("%d", &seq_value);

  while (seq_value > 0) {
    if (mmmc_atual == 0) {
      printf("Digite um valor: ");
      scanf("%d", &valor_a);
      // Diminuindo a sequencia
      printf("Digite mais um valor: ");
      scanf("%d", &valor_b);
      mmmc_atual = mmcCalculo(valor_a, valor_b);
      seq_value -= 2;
      if (seq_value <= 0) {
        break;
      }
    }
    else if (mmmc_atual != 0) {
      printf("Digite um valor: ");
      scanf("%d", &valor_a);
      mmmc_atual = mmcCalculo(mmmc_atual, valor_a);
      // Diminuindo a sequencia
      seq_value --;
      if (seq_value <= 0) {
        break;
      }
      printf("Digite mais um valor: ");
      scanf("%d", &valor_b);
      mmmc_atual = mmcCalculo(mmmc_atual, valor_b);
      seq_value --;
      if (seq_value <= 0) {
        break;
      }
    }
  }

  printf("O MMC e: %d", mmmc_atual);

  return 0;
}
