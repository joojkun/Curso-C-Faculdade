#include <stdio.h>
#include <math.h>

int calcula_raizes(float a, float b, float c, float *x1, float *x2) {
  float delta = (b * b) - 4 * a * c;
  
  // Primeira raíz
  *x1 = (- b + sqrt(delta)) / (2*a);
  // Segunda raíz
  *x2 = (- b - sqrt(delta)) / (2*a);
  
  // Duas raízes reais
  if (delta > 0) {
    return 2;
  }
  // Uma raíz real
  else if (delta == 0) {
    return 1;
  }
  // Nenhuma raíz real
  else if (delta < 0){
    return 0;
  }
}

int main() {
  // Valores que serão lidos
  float valor_a, valor_b, valor_c;
  // Ponteiros das raízes
  float raiz_1, raiz_2;
  // Resultado da função
  int funcao_raizes;

  // Lendo os valores
  printf("Digite um valor: ");
  scanf("%f", &valor_a);
  printf("Digite um segundo valor: ");
  scanf("%f", &valor_b);
  printf("Digite um terceiro valor: ");
  scanf("%f", &valor_c);

  // Executando a função
  funcao_raizes = calcula_raizes(valor_a, valor_b, valor_c, &raiz_1, &raiz_2);

  // Imprimindo o resultado
  if (funcao_raizes == 1) {
    printf("A função possui apenas uma raiz real, sendo ela %.2f.", raiz_1);
  }
  else if (funcao_raizes == 2) {
    printf("A funcao possui duas raizes reais, sendo elas %.2f e %.2f.",
     raiz_1, raiz_2);
  }
  else {
    printf("A funcao nao possui nenhuma raiz real.");
  }
}
