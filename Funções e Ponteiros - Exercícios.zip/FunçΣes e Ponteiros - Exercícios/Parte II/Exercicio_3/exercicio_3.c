#include <stdio.h>
#include <stdbool.h>

void converteHora(int total_segundos, int *hora, int *min, int *seg) {
  while (total_segundos >= 60) {
    total_segundos -= 60;
    // Aumentando minutos
    *min = *min + 1;
    // Aumentando Horas
    if (*min == 60) {
      *hora = *hora + 1;
      *min = 0;
    }
  }
  printf("%.2d : %.2d: %.2d", *hora, *min, total_segundos);
}

int main() {
  // Valore que será lido
  int valor_segundos;
  // Variáveis passadas para os ponteiros
  int hora = 0, minuto = 0, segundo = 0;

  // Lendo o valor
  printf("Digite um valor em segundos: ");
  scanf("%d", &valor_segundos);

  // Executando a função
  converteHora(valor_segundos, &hora, &minuto, &segundo);
}
