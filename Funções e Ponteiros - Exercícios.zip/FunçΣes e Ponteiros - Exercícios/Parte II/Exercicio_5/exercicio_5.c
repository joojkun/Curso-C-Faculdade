#include <stdio.h>

void removeExtremos(int *n, int *pri, int *ult)
{
  int tn,pot;
  *ult = *n % 10;
  pot=1;
  tn = *n;

  while(tn >= 10){
    tn = tn/10;
    pot *= 10;
  }
  *pri = *n / pot;
  *n = *n % pot;
  *n = *n / 10;
}

int main() {
  // Variável que verifica se o número é palindromo
 int palindromo_ver = 1;
 // Valor que será lido e cópia do valor lido
 int valor_lido, vl_copy;
 // Primeiro e último dígito do valor
 int p_digito, u_digito;

 // Lendo os valores
 printf("Digite um valor: ");
 scanf("%d", &valor_lido);
 vl_copy = valor_lido;

 // Executando a função
 while (p_digito != 0 && u_digito != 0) {
   removeExtremos(&valor_lido, &p_digito, &u_digito);

   // Caso sejam achados caractéres diferentes
   if (p_digito != u_digito) {
     palindromo_ver = 0;
   }
 }

 // Verificando se é palíndromo
 // Caso seja
 if (palindromo_ver == 1) {
   printf("O valor %d e um palindromo!", vl_copy);
 }
 else {
   printf("O valor %d nao e um palindromo!", vl_copy);
 }

}
