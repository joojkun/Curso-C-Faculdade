#include <stdio.h>

void questao01(int *a, int *b) {
  *a = *a - 1;
  *b = *b + 1;
  printf("Valor decrementado: %d | Valor incrementado: %d",
   *a, *b);
}

int main() {
  // Valores que serão lidos
  int valor_1, valor_2;

  // Lendo os valores
  printf("Digite um valor: ");
  scanf("%d", &valor_1);
  printf("Digite mais um valor: ");
  scanf("%d", &valor_2);

  // Executando a função
  questao01(&valor_1, &valor_2);
  // Resultado
  return 0;
}