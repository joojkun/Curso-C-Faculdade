#include <stdio.h>
/* Faça um programa que leia dois valores do teclado, n1 e n2, e usando o método
 da fatoração, calcule o Mínimo Múltiplo Comun (MMC) de n1 e n2. */

 int calculoMDC(int valor_1, int valor_2) {
  // Calculando o M.D.C.
  while(valor_1 != valor_2){
    if (valor_1 > valor_2){
      valor_1 -= valor_2;
    }
    else if (valor_2 > valor_1) {
      valor_2 -= valor_1;
    }
    else {
      return valor_1;
    }
  }
  return valor_1;
 }

int main(){
  // Valores que serão lidos
  int valor_1, valor_2;
  // Multiplos dos números e valor do MMC
  int multiplo = 2, mdc_valor = 1;

  // Lendo os valores
  printf("Digite um valor: ");
  scanf("%d", &valor_1); // Primeiro valor
  printf("Digite outro valor: ");
  scanf("%d", &valor_2); // Segundo valor

  // Imprimindo resultado
  printf("%d\n", calculoMDC(valor_1, valor_2));
  return 0;
}
