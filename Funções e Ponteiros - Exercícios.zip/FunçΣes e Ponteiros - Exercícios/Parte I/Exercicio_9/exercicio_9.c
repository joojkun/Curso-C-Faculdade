#include <stdio.h>

float calculoIMC(float peso, float altura) {
  return (peso / (altura * altura));
}

void msgIMC(float imc){
  if (18.5 > imc){
    printf("Voce esta abaixo do peso");
  }
  else if (imc >= 18.5 && imc < 25) {
    printf("Voce esta no peso normal");
  }
  else if (imc >= 25 && imc <= 30) {
    printf("Voce esta acima do peso");
  }
  else if (imc > 30) {
    printf("Voce esta obeso");
  }
}


int main(void) {
  // Valores que serão lidos
  float peso, altura;
  float imc;

  // Lendo valores
  printf("Digite seu peso: ");
  scanf("%f", &peso);
  printf("Digite sua altura: ");
  scanf("%f", &altura);
  
  // IMC
  imc = calculoIMC(peso, altura);
  
  printf("Seu IMC e: %.2f\n", imc);
  msgIMC(imc);
  
  return 0;
}
