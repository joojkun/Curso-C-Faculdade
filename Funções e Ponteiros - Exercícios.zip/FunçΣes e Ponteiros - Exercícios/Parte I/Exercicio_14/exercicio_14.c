#include <stdio.h>
#include <math.h>

int numRegular(int n) {
  // Fatores
  int a = 2, b = 3, c = 5;
  int pot_a, pot_b, pot_c;
  int result;
  for (int exp_a = 1; exp_a <= n; exp_a ++) {
    pot_a = pow(a, exp_a);
    if (pot_a > n) {
      break;
    }
    for (int exp_b = 1; exp_b <= n; exp_b ++) {
      pot_b = pow(b, exp_b);
      if (pot_b > n) {
        break;
      }
      for (int exp_c = 1; exp_c <= n; exp_c++) {
        pot_c = pow(c, exp_c);
        if (pot_c % 10 == 4) {
          pot_c ++;
        }
        result = pot_a * pot_b * pot_c;
        // Caso seja regular
        if (result == n) {
          printf("%d^%d * %d^%d * %d^%d = %d\n",
          a, exp_a, b, exp_b, c, exp_c, result);
          return 1;
        }
        else if (result > n) {
          break;
        }
      }
    }
  }
  // Caso não seja regular
  return 0;
}

int main () {
  // Valor que será lido
  int valor_lido;
  // Resultado
  int result;

  // Lendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_lido);

  // Executando a função
  result = numRegular(valor_lido);
  // Verificando se o valor é regular
  if (result == 1) {
    printf("O valor %d e regular.", valor_lido);
  }
  else {
    printf("O valor %d nao e regular.", valor_lido);
  }
  return 0;
}
