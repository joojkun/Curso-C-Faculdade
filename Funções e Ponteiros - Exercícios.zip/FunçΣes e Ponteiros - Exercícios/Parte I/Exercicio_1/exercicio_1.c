#include <stdio.h>

// Função que verifica se o ano é bissexto
int anoBissexto(ano){
  // Caso seja bissexto
  if (ano % 4 == 0) {
    if (ano % 100 != 0 || ano % 400 == 0){
      return 1;
    }
    // Caso não seja bissexto
    else {
      return 0;
    }
  }
  // Caso não seja bissexto
  else {
    return 0;
  }
}

int main(){
  // Valor que será lido
  int valor_lido;
  // Resultado
  int result; 

  // Lendo o valor
  printf("Digite um ano qualquer: ");
  scanf("%d", &valor_lido);

  // Executando função
  result = anoBissexto(valor_lido);

  if (result == 1) {
    printf("%d e um ano bissexto", valor_lido);
  }
  else {
    printf("%d nao e um ano bissexto", valor_lido);
  }
  return 0;
}
