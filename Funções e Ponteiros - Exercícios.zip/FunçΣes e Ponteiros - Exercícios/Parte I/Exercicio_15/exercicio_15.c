#include <stdio.h>

int verSegmento(int seq) {
  // Sequência impar, par, ou alternada
  int ver_impar = 0, ver_par = 0;
  // Valor atual digitado
  int valor_atual;

  // Lendo a sequência
  for (int i = 1; i <= seq; i ++) {
    // Lendo um valor
    printf("Digite um valor: ");
    scanf("%d", &valor_atual);

    // Verificando o valor
    // Par
    if (valor_atual % 2 == 0) {
      ver_par = 1;
    }
    // Impar
    else if (valor_atual % 2 != 0) {
      ver_impar = 1;
    }
  }

  // Retornando o valor da sequência
  if (ver_par == 1 && ver_impar == 0) { // Par
    return 0;
  }
  else if (ver_impar == 1 && ver_par == 0) { // Impar
    return 1;
  }
  else if (ver_impar == 1 && ver_par == 1) { // Alternada
    return -1;
  }
}

int main() {
  // Valor do segmento
  int seg_valor;
  // Verificação do segmento
  int result;
  // Verifica se é piramidal
  int ver_piramidal = 1;
  // Alternante da piramidal
  int i = 1;
  // Lendo o valor do Segmento
  printf("Digite um valor: ");
  scanf("%d", &seg_valor);

  // Lendo o segmento
  while (seg_valor > 0) {
    if (seg_valor - i > 0) {
      // Lendo o segmento
      result = verSegmento(i);
      seg_valor -= i;

      if (result == -1) {
        ver_piramidal = 0;
      }
    }
    else if (seg_valor - i == 0) {
      // Lendo o segmento
      result = verSegmento(i);
      seg_valor -= i;
      if (result == -1) {
        ver_piramidal = 0;
      }
    }
    else if (seg_valor - i < 0){
      // Lendo o segmento
      result = verSegmento(seg_valor);
      seg_valor -= i;
      ver_piramidal = 0;
    }
    i ++;
    printf("\n");
  }

  if (ver_piramidal == 1) {
    printf("E piramidal %d-alternante", i - 1);
  }
  else {
    printf("Nao e piramidal alternante");
  }
  
  return 0;
}