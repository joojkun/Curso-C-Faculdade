#include <stdio.h>

int retornaResto(int alexandre, int maria, int rafael) {
  return (alexandre + maria + rafael) % 3;
}

void imprimeVencedor(int resto) {
  if (resto == 0) {
    printf("O vencedor foi Alexandre!");
  }
  else if (resto == 1) {
    printf("A vencedora foi Maria!");
  }
  else if (resto == 2) {
    printf("O vencedor foi Rafael!");
  }
}

int main() {
  // Valor que será lido
  int alexandre, maria, rafael;
  // Resultado do jogo
  int result;

  // Lendo os valores
  printf("De a entrada para alexandre: ");
  scanf("%d", &alexandre);
  printf("De a entrada para Maria: ");
  scanf("%d", &maria);
  printf("De a entrada para Rafael: ");
  scanf("%d", &rafael);

  // Resultado
  result = retornaResto(alexandre, maria, rafael);
  imprimeVencedor(result);
}
