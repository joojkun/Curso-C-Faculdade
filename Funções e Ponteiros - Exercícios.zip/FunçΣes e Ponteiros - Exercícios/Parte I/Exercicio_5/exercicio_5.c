#include <stdio.h>

int retornaMaior(int n1, int n2) {
  // Comparando os dois valores
  if (n1 > n2) {
    return n1;
  }
  else if (n2 > n1) {
    return n2;
  }
  else {
    return n1;
  }
}

int main(void) {
  // Valor que será lido
  int valor1, valor2;
  
  // Primeiro valor
  printf("Digite um valor: " );
  scanf("%d", &valor1);

  // Segundo valor
  printf("Digite mais um valor: ");
  scanf("%d", &valor2);

  // Executando a função
  printf("O maior valor e: %d", retornaMaior(valor1, valor2));
  
  return 0;
}