#include <stdio.h>
/* Escreva uma função que recebe um caractere e retorna 1 se o caractere for uma letra maiúscula, 2 se for uma letra minúscula, 3 se for um dígito e 0 do contrário. Protótipo: int testaTipoChar (char c); */

int testaTipoChar(char c){
  // Convertendo o char
  int convert_c = c;

  // Caso seja minúsculo
  if (convert_c >= 97 && convert_c <= 122) {
    return 1;
  }
  // Caso seja maiúsculo
  else if (convert_c >= 65 && convert_c <= 90) {
    return 2;
  }
  // Caso seja número
  else if (convert_c >= 48 && convert_c <= 57) {
    return 3;
  }
  else {
    return 0;
  }

  
}
int main(void) {
  // Valor que será lido
  char valor_lido;
  
  // Lendo o valor
  printf("Digite um caractere: ");
  scanf("%c", &valor_lido);

  // Executando a função
  printf("%d", testaTipoChar(valor_lido));
  
  return 0;
}