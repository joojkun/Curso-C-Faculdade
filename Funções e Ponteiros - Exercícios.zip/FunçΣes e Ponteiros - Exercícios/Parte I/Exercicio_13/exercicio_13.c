#include <stdio.h>

int verDigitos(int valor_1, int valor_2) {
  int cont_digitos = 0, ver_cont = 0;
  int valor_2_copia = valor_2;
  // Fatorando o primeiro valor
  while (valor_2_copia != 0) {
    valor_2_copia /= 10;
    cont_digitos ++;
  }
  // Verificando a igualdade dos dígitos
  for (int i = 1; i <= cont_digitos; i++) {
    if (valor_1 % 10 == valor_2 % 10){
      ver_cont ++;
      valor_1 /= 10;
      valor_2 /= 10;
    }
  }

  // Caso valor_2 pertença a valor_1
  if (cont_digitos == ver_cont){
    return 1;
  }
  // Caso valor_2 não pertença a valor_1
  else {
    return 0;
  }

}

int verSegmento(valor_1, valor_2) {
  // Resultado da checagem de segmento
  int seg_ver = 0;

  while (valor_1 != 0) {
    if (valor_1 % 10 == valor_2 % 10) {
      // Verificando se valor 2 é segmento de valor 1
      seg_ver = verDigitos(valor_1, valor_2);
      // Caso valor 2 seja segmento de valor 1
      if (seg_ver == 1) {
        return 1;
      }
    }
    else {
      valor_1 /= 10;
    }
  }
  return 0;
}

int main() {
  // Valores que serão lidos
  int valor_a, valor_b;
  // Resultado da checagem
  int result;

  // Lendo o valor
  printf("Digite um valor: ");
  scanf("%d", &valor_a);
  printf("Digite outro valor: ");
  scanf("%d", &valor_b);

  if (valor_a > valor_b) {
    // Executando a função
    result = verSegmento(valor_a, valor_b);
    // Se B for segmento de A    
    if (result == 1) {
      printf("%d e segmento de %d", valor_b, valor_a);
    }
    else {
      printf("%d nao e segmento de %d", valor_b, valor_a);
    }
  }
  else if (valor_b > valor_a) {
    // Executando a função
    result = verSegmento(valor_b, valor_a);
    // Se B for segmento de A    
    if (result == 1) {
      printf("%d e segmento de %d", valor_a, valor_b);
    }
    else {
      printf("%d nao e segmento de %d", valor_a, valor_b);
    }
  }
  else if (valor_a == valor_b) {
    printf("%d e segmento de %d", valor_a, valor_b);
  }

  return 0;
}
