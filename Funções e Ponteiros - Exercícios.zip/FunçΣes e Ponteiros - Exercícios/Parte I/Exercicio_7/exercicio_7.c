#include <stdio.h>
#include <math.h>

int flag = 0;

void convertToBinario(int n){
  if(n == 0)
    if (flag == 0){
      flag = 1;
    }
    else {
      printf("%d", n);
    }
  else{
    convertToBinario(n/2);
    printf("%d", n % 2);
  }
}

int convertToDecimal(int valor) {
  int expoente = 0, base;
  int valor_decimal = 0;
  // Convertendo o valor utilizando o método posicional
  while (valor != 0){
    base = pow(2, expoente);
    base *= valor % 10;
    valor_decimal += base;
    expoente ++;
    valor /= 10;
  }
  // Retornando valor decimal
  return valor_decimal;
}

int main () {
  // Opção
  int opcao;
  // Valor que será convertido
  int valor_lido;

  while (1 < 2){
    // Perguntando a opção
    printf("Voce deseja:\n- Converter um numero de"
    " binário para decimal (digite 1);\n- Converter de" 
    "decimal para binario (digite 2)\n- Encerrar (digite 0): ");
    scanf("%d",&opcao);
  
    if (opcao == 1){
      printf("Digite um valor decimal para ser convertido: ");
      scanf("%d", &valor_lido);
      printf("%d", convertToDecimal(valor_lido));
    }
    else if (opcao == 2){
      printf("Digite um valor decimal para ser convertido: ");
      scanf("%d", &valor_lido);
      convertToBinario(valor_lido);
    }
    else {
      break;
    }
    printf("\n\n");
  }

  return 0;
}
